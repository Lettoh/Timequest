package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandeNetherCraft {

    private final TimeQuest plugin;

    public OffrandeNetherCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
        craft2();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Nether 1");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("vnv","nqn","vnv");
        offrande.setIngredient('v', Material.NETHER_WART);
        offrande.setIngredient('n', Material.NETHERRACK);
        offrande.setIngredient('q', Material.QUARTZ);

        plugin.getServer().addRecipe(offrande);
    }

    private void craft2(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Nether 2");
        item.setItemMeta(meta);

        NamespacedKey key = new NamespacedKey(plugin,"offrande_nether");
        ShapedRecipe offrande = new ShapedRecipe(key, item);

        offrande.shape(" b ","mnm"," b ");
        offrande.setIngredient('b', Material.BLAZE_POWDER);
        offrande.setIngredient('m', Material.MAGMA_BLOCK);
        offrande.setIngredient('n', Material.NETHER_BRICKS);

        plugin.getServer().addRecipe(offrande);
    }
}
