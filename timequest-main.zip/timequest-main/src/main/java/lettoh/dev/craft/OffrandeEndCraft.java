package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandeEndCraft {

    private final TimeQuest plugin;

    public OffrandeEndCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
        craft2();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande End 1");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("vbv","beb","vbv");
        offrande.setIngredient('v', Material.PURPUR_BLOCK);
        offrande.setIngredient('b', Material.STONE_BRICKS);
        offrande.setIngredient('e', Material.ENDER_PEARL);

        plugin.getServer().addRecipe(offrande);
    }
    private void craft2(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande End 2");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("cec"," d ","cec");
        offrande.setIngredient('c', Material.CHORUS_FRUIT);
        offrande.setIngredient('e', Material.END_STONE);
        offrande.setIngredient('d', Material.DRAGON_BREATH);

        plugin.getServer().addRecipe(offrande);
    }
}
