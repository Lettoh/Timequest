package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandeUltimeCraft {

    private final TimeQuest plugin;

    public OffrandeUltimeCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Ultime");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("scb","odo","bcs");
        offrande.setIngredient('s', Material.SOUL_SAND);
        offrande.setIngredient('c', Material.COCOA_BEANS);
        offrande.setIngredient('b', Material.SNOW_BLOCK);
        offrande.setIngredient('o', Material.CHORUS_FRUIT);
        offrande.setIngredient('d', Material.DIAMOND);

        plugin.getServer().addRecipe(offrande);
    }
}
