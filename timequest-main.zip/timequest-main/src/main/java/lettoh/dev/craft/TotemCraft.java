package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionType;

public class TotemCraft {
    private final TimeQuest plugin;

    public TotemCraft (TimeQuest plugin)
    {
        this.plugin = plugin;
    }

    public void register()
    {
        ItemStack item = new ItemStack(Material.TOTEM_OF_UNDYING);

        ShapedRecipe totem = new ShapedRecipe(item);

        totem.shape("geg","ggg"," g ");
        totem.setIngredient('e', Material.EMERALD_BLOCK);
        totem.setIngredient('g', Material.GOLD_BLOCK);

        plugin.getServer().addRecipe(totem);
    }
}
