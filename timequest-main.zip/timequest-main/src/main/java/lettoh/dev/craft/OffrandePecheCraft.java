package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandePecheCraft {

    private final TimeQuest plugin;

    public OffrandePecheCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
        craft2();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Pêche 1");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("scs","cpc","scs");
        offrande.setIngredient('s', Material.SAND);
        offrande.setIngredient('c', Material.SUGAR_CANE);
        offrande.setIngredient('p', Material.SALMON);

        plugin.getServer().addRecipe(offrande);
    }

    private void craft2(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Pêche 2");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("scs","cpc","scs");
        offrande.setIngredient('s', Material.SAND);
        offrande.setIngredient('c', Material.SUGAR_CANE);
        offrande.setIngredient('p', Material.COD);

        plugin.getServer().addRecipe(offrande);
    }
}
