package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandeAgriCraft {

    private final TimeQuest plugin;

    public OffrandeAgriCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
        craft2();
        craft3();
        craft4();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Agriculture 1");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("msm","sbs","msm");
        offrande.setIngredient('m', Material.MELON);
        offrande.setIngredient('s', Material.WHEAT_SEEDS);
        offrande.setIngredient('b', Material.WHEAT);

        plugin.getServer().addRecipe(offrande);
    }
    private void craft2(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Agriculture 2");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("psp","tbt","psp");
        offrande.setIngredient('p', Material.CARVED_PUMPKIN);
        offrande.setIngredient('s', Material.WHEAT_SEEDS);
        offrande.setIngredient('t', Material.DIRT);
        offrande.setIngredient('b', Material.WHEAT);

        plugin.getServer().addRecipe(offrande);
    }
    private void craft3(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Agriculture 3");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("csc","nbn","csc");
        offrande.setIngredient('c', Material.CARROT);
        offrande.setIngredient('s', Material.WHEAT_SEEDS);
        offrande.setIngredient('n', Material.SNOW_BLOCK);
        offrande.setIngredient('b', Material.WHEAT);

        plugin.getServer().addRecipe(offrande);
    }
    private void craft4(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Agriculture 4");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("psp","owo","psp");
        offrande.setIngredient('p', Material.POTATO);
        offrande.setIngredient('s', Material.WHEAT_SEEDS);
        offrande.setIngredient('o', Material.SNOW_BLOCK);
        offrande.setIngredient('w', Material.WHEAT);

        plugin.getServer().addRecipe(offrande);
    }
}
