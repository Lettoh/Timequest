package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public class XpBottleCraft {

    private final TimeQuest plugin;

    public XpBottleCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
        craft2();
    }

    private void craft (){
        ItemStack bottle = new ItemStack(Material.EXPERIENCE_BOTTLE,6);
        ShapedRecipe expBottle = new ShapedRecipe(bottle);

        expBottle.shape("vlv"," v ","   ");
        expBottle.setIngredient('l', Material.LAPIS_LAZULI);
        expBottle.setIngredient('v', Material.GLASS);

        plugin.getServer().addRecipe(expBottle);
    }

    private void craft2(){
        ItemStack bottle = new ItemStack(Material.EXPERIENCE_BOTTLE, 6);
        ShapedRecipe expBottle = new ShapedRecipe(bottle);

        expBottle.shape("   ","vlv"," v ");
        expBottle.setIngredient('l', Material.LAPIS_LAZULI);
        expBottle.setIngredient('v', Material.GLASS);

        plugin.getServer().addRecipe(expBottle);
    }
}
