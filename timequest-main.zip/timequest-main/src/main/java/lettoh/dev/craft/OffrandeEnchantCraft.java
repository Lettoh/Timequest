package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandeEnchantCraft {

    private final TimeQuest plugin;

    public OffrandeEnchantCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Enchanteur");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("lpl","pbp","lpl");
        offrande.setIngredient('l', Material.LAPIS_LAZULI);
        offrande.setIngredient('p', Material.PAPER);
        offrande.setIngredient('b', Material.BOOKSHELF);

        plugin.getServer().addRecipe(offrande);
    }
}
