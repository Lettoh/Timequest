package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandeMineCraft {

    private final TimeQuest plugin;

    public OffrandeMineCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
        craft2();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Mine 2");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("cbc","bob","cbc");
        offrande.setIngredient('c', Material.COAL);
        offrande.setIngredient('b', Material.OAK_PLANKS);
        offrande.setIngredient('o', Material.GOLD_INGOT);

        plugin.getServer().addRecipe(offrande);
    }
    private void craft2(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Mine 1");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("rbr","bib","rbr");
        offrande.setIngredient('r', Material.REDSTONE);
        offrande.setIngredient('b', Material.OAK_PLANKS);
        offrande.setIngredient('i', Material.IRON_INGOT);

        plugin.getServer().addRecipe(offrande);
    }
}
