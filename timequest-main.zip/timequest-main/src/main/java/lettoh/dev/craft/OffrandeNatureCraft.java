package lettoh.dev.craft;

import lettoh.dev.TimeQuest;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class OffrandeNatureCraft {

    private final TimeQuest plugin;

    public OffrandeNatureCraft (TimeQuest plugin){
        this.plugin = plugin;
    }

    public void register(){
        craft();
        craft2();
        craft3();
    }

    private void craft(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Nature 1");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("bgb","cnc","bgb");
        offrande.setIngredient('b', Material.BAMBOO);
        offrande.setIngredient('g', Material.GLASS);
        offrande.setIngredient('c', Material.BRICK);
        offrande.setIngredient('n', Material.LILY_PAD);

        plugin.getServer().addRecipe(offrande);
    }
    private void craft2(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Nature 2");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("kok","vdv","kok");
        offrande.setIngredient('k', Material.KELP);
        offrande.setIngredient('o', Material.COBBLESTONE);
        offrande.setIngredient('v', Material.VINE);
        offrande.setIngredient('d', Material.DANDELION);

        plugin.getServer().addRecipe(offrande);
    }

    private void craft3(){
        ItemStack item = new ItemStack(Material.BEDROCK);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("Offrande Nature 3");
        item.setItemMeta(meta);

        ShapedRecipe offrande = new ShapedRecipe(item);

        offrande.shape("coc","ara","coc");
        offrande.setIngredient('c', Material.COCOA_BEANS);
        offrande.setIngredient('o', Material.COBBLESTONE);
        offrande.setIngredient('a', Material.CACTUS);
        offrande.setIngredient('r', Material.POPPY);

        plugin.getServer().addRecipe(offrande);
    }
}
