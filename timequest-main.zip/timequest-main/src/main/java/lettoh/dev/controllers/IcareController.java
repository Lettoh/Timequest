package lettoh.dev.controllers;

import lettoh.dev.database.Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class IcareController extends Database {
    public boolean hasTeamFinishedIcare(Integer team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("SELECT * from icare where team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result_set = statement.executeQuery();

        if (result_set.next())
        {
            statement.close();
            return true;
        }

        statement.close();

        return false;
    }
    public void addIcare(Integer team_id) throws SQLException {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO icare(team_id) VALUE (?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();
        statement.close();
    }
}
