package lettoh.dev.controllers;

import lettoh.dev.database.Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QuestController extends Database {

    public boolean hasAnnexe0(int team_id) throws SQLException
    {
        boolean found = false;

        PreparedStatement statement = getConnection().prepareStatement("SELECT * from annexe_0 WHERE team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result = statement.executeQuery();

        if (result.next()) found = true;
        statement.close();

        return found;
    }

    public void setAnnexe0(int team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO annexe_0 VALUES(?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();

        statement.close();
    }

    public boolean hasAnnexe1(int team_id) throws SQLException
    {
        boolean found = false;

        PreparedStatement statement = getConnection().prepareStatement("SELECT * from annexe_1 WHERE team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result = statement.executeQuery();

        if (result.next()) found = true;
        statement.close();

        return found;
    }

    public void setAnnexe1(int team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO annexe_1 VALUES(?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();

        statement.close();
    }

    public boolean hasAnnexe2(int team_id) throws SQLException
    {
        boolean found = false;

        PreparedStatement statement = getConnection().prepareStatement("SELECT * from annexe_2 WHERE team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result = statement.executeQuery();

        if (result.next()) found = true;
        statement.close();

        return found;
    }

    public void setAnnexe2(int team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO annexe_2 VALUES(?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();

        statement.close();
    }

    public boolean hasAnnexe3(int team_id) throws SQLException
    {
        boolean found = false;

        PreparedStatement statement = getConnection().prepareStatement("SELECT * from annexe_3 WHERE team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result = statement.executeQuery();

        if (result.next()) found = true;
        statement.close();

        return found;
    }

    public void setAnnexe3(int team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO annexe_3 VALUES(?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();

        statement.close();
    }

    public boolean hasAnnexe4(int team_id) throws SQLException
    {
        boolean found = false;

        PreparedStatement statement = getConnection().prepareStatement("SELECT * from annexe_4 WHERE team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result = statement.executeQuery();

        if (result.next()) found = true;
        statement.close();

        return found;
    }

    public void setAnnexe4(int team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO annexe_4 VALUES(?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();

        statement.close();
    }
}
