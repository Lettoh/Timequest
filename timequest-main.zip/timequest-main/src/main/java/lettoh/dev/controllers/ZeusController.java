package lettoh.dev.controllers;

import lettoh.dev.database.Database;
import lettoh.dev.model.TeamModel;
import org.checkerframework.checker.units.qual.A;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ZeusController extends Database {
    public boolean hasTeamFinishedZeus(Integer team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("SELECT * from zeus where team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result_set = statement.executeQuery();

        if (result_set.next())
        {
            statement.close();
            return true;
        }

        statement.close();

        return false;
    }

    public void addZeus(Integer team_id) throws SQLException {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO zeus(team_id) VALUE (?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();
        statement.close();
    }

    public ArrayList<Integer> getTeamsIds() throws SQLException {
        PreparedStatement statement = getConnection().prepareStatement("SELECT * from zeus");

        ResultSet result = statement.executeQuery();
        ArrayList<Integer> teams = new ArrayList<>();

        while (result.next())
        {
            teams.add(result.getInt("team_id"));
        }

        return teams;
    }
}
