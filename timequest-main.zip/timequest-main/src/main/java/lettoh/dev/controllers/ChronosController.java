package lettoh.dev.controllers;

import lettoh.dev.database.Database;
import lettoh.dev.model.Chronos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ChronosController extends Database {
    public boolean hasTeamFinishedChronos(Integer team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("SELECT * from chronos where team_id = ?");
        statement.setInt(1, team_id);

        ResultSet result_set = statement.executeQuery();

        Chronos chronos_player;

        if (result_set.next())
        {
            statement.close();
            return true;
        }

        statement.close();

        return false;
    }
    public void addChronos(Integer team_id) throws SQLException {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO chronos(team_id) VALUE (?)");
        statement.setInt(1, team_id);

        statement.executeUpdate();
        statement.close();
    }
}
