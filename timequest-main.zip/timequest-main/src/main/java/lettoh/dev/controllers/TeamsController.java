package lettoh.dev.controllers;

import lettoh.dev.database.Database;
import lettoh.dev.model.TeamModel;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.UUID;

public class TeamsController extends Database {

    public TeamModel findTeamById(int id) throws SQLException
    {
        PreparedStatement statement = getConnection()
                .prepareStatement("SELECT * FROM teams WHERE id = ?");
        statement.setInt(1, id);

        ResultSet result = statement.executeQuery();
        if (result.next())
        {
            TeamModel teamModel = new TeamModel();
            teamModel.setId(result.getInt("id"));
            teamModel.setName(result.getString("name"));
            teamModel.setTag(result.getString("tag"));
            teamModel.setColor(result.getString("color"));
            teamModel.setScore(result.getLong("score"));

            statement.close();
            return teamModel;
        }

        statement.close();
        return null;
    }

    public TeamModel findTeamByPlayer(Player player) throws SQLException
    {
        String player_uuid = player.getUniqueId().toString();

        PreparedStatement statement = getConnection()
                .prepareStatement("SELECT * FROM teams INNER JOIN player_team ON teams.id = player_team.team_id WHERE player_team.player_uuid = ?");
        statement.setString(1, player_uuid);

        ResultSet result = statement.executeQuery();
        if (result.next())
        {
            TeamModel teamModel = new TeamModel();
            teamModel.setId(result.getInt("id"));
            teamModel.setName(result.getString("name"));
            teamModel.setTag(result.getString("tag"));
            teamModel.setColor(result.getString("color"));
            teamModel.setScore(result.getLong("score"));

            statement.close();
            return teamModel;
        }

        statement.close();
        return null;
    }

    public TeamModel findTeamByName(String name) throws SQLException
    {
        PreparedStatement statement = getConnection()
                .prepareStatement("SELECT * FROM teams WHERE name = ?");
        statement.setString(1, name);

        ResultSet result = statement.executeQuery();
        if (result.next())
        {
            TeamModel teamModel = new TeamModel();
            teamModel.setId(result.getInt("id"));
            teamModel.setName(result.getString("name"));
            teamModel.setTag(result.getString("tag"));
            teamModel.setColor(result.getString("color"));
            teamModel.setScore(result.getLong("score"));

            statement.close();
            return teamModel;
        }

        statement.close();
        return null;
    }

    public ArrayList<Player> findPlayersByTeam(int team_id) throws SQLException
    {
        ArrayList<Player> player_list = new ArrayList<>();

        PreparedStatement statement = getConnection()
                .prepareStatement("SELECT * FROM player_team INNER JOIN teams ON player_team.team_id = teams.id WHERE teams.id = ?");
        statement.setInt(1, team_id);

        ResultSet result = statement.executeQuery();

        while (result.next())
        {
            String player_uuid = result.getString("player_uuid");

            Player player = Bukkit.getPlayer(UUID.fromString(player_uuid));

            if (player != null)
            {
                player_list.add(player);
            }
        }

        statement.close();
        return player_list;
    }

    public ArrayList<TeamModel> getByScore() throws SQLException
    {
        Statement statement = getConnection().createStatement();
        ResultSet result = statement.executeQuery("SELECT * from teams ORDER BY score DESC");

        ArrayList<TeamModel> ranking = new ArrayList<>();

        while (result.next())
        {
            TeamModel team = new TeamModel();
            team.setId(result.getInt("id"));
            team.setName(result.getString("name"));
            team.setColor(result.getString("color"));
            team.setScore(result.getLong("score"));

            ranking.add(team);
        }

        return ranking;
    }

    public TeamModel createTeam(String name, String tag, String color) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO teams VALUES(null, ?, ?, ?, 0)", PreparedStatement.RETURN_GENERATED_KEYS);
        statement.setString(1, name);
        statement.setString(2, tag);
        statement.setString(3, color);

        statement.executeUpdate();
        ResultSet result_set = statement.getGeneratedKeys();
        result_set.next();

        int generated_team_id = result_set.getInt(1);
        statement.close();

        TeamModel team_model = findTeamById(generated_team_id);

        return team_model;
    }

    public void deleteTeam(int team_id) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("DELETE FROM teams WHERE id = ?");
        statement.setInt(1, team_id);

        statement.executeUpdate();
        statement.close();
    }

    public void addPlayerToTeam(Player player, TeamModel team_model) throws Exception
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO player_team VALUES(null, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
        statement.setInt(1, team_model.getId());
        statement.setString(2, player.getUniqueId().toString());

        statement.executeUpdate();
        ResultSet result_set = statement.getGeneratedKeys();

        if (!result_set.next()) throw new Exception();
        statement.close();
    }

    public void removePlayerFromTeam(Player player, TeamModel team_model) throws Exception
    {
        PreparedStatement statement = getConnection().prepareStatement("DELETE FROM player_team WHERE player_uuid = ? AND team_id = ?");
        statement.setString(1, player.getUniqueId().toString());
        statement.setInt(2, team_model.getId());

        statement.executeUpdate();
        statement.close();
    }

    public TeamModel addScore(TeamModel team, Long score) throws SQLException {

        Long old_score = team.getScore();

        PreparedStatement statement = getConnection().prepareStatement("UPDATE teams SET score = ? WHERE id = ?");
        statement.setLong(1, old_score + score);
        statement.setInt(2, team.getId());

        statement.executeUpdate();
        statement.close();

        return team;
    }
}
