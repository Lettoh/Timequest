package lettoh.dev.controllers;

import lettoh.dev.database.Database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InfosController extends Database {
    public Boolean getEndEnabled() throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("SELECT end_enabled from infos");

        ResultSet result = statement.executeQuery();
        if (result.next())
        {
            return (result.getBoolean("end_enabled"));
        }

        return false;
    }

    public Boolean getChatDisabled() throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("SELECT chat_disabled from infos");

        ResultSet result = statement.executeQuery();
        if (result.next())
        {
            return (result.getBoolean("chat_disabled"));
        }

        return false;
    }

    public Boolean getBankDisabled() throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("SELECT bank_disabled from infos");

        ResultSet result = statement.executeQuery();
        if (result.next())
        {
            return (result.getBoolean("bank_disabled"));
        }

        return false;
    }

    public void setBankDisabled(Boolean bool) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("UPDATE infos SET bank_disabled = ? WHERE id = 1");
        statement.setBoolean(1, bool);

        statement.execute();
    }

    public void setChatDisabled(Boolean bool) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("UPDATE infos SET chat_disabled = ? WHERE id = 1");
        statement.setBoolean(1, bool);

        statement.execute();
    }

    public void setEndEnabled(Boolean bool) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("UPDATE infos SET end_enabled = ? WHERE id = 1");
        statement.setBoolean(1, bool);

        statement.execute();
    }
}
