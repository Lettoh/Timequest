package lettoh.dev.controllers;

import lettoh.dev.database.Database;
import lettoh.dev.model.PlayerMute;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PlayerMuteController extends Database {

    public ArrayList<PlayerMute> getAll() throws SQLException {
        ArrayList<PlayerMute> list = new ArrayList<>();

        PreparedStatement statement = getConnection().prepareStatement("SELECT * from player_mute");
        ResultSet result_set = statement.executeQuery();

        PlayerMute muted_player;

        while (result_set.next())
        {
            muted_player = new PlayerMute(result_set.getString("player_uuid"));
            list.add(muted_player);
        }

        statement.close();

        return list;
    }
    public PlayerMute findMutedPlayerByUUID(String uuid) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("SELECT * from player_mute where player_uuid = ?");
        statement.setString(1, uuid);

        ResultSet result_set = statement.executeQuery();

        PlayerMute muted_player;

        if (result_set.next())
        {
            muted_player = new PlayerMute(result_set.getString("player_uuid"));

            statement.close();

            return muted_player;
        }

        statement.close();

        return null;
    }
    public void createPlayerMute(PlayerMute muted_player) throws SQLException {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO player_mute(player_uuid) VALUE (?)");
        statement.setString(1, muted_player.getPlayerUuid());

        statement.executeUpdate();
        statement.close();
    }

    public void deletePlayerMute(PlayerMute muted_player) throws SQLException {
        PreparedStatement statement = getConnection().prepareStatement("DELETE FROM player_mute WHERE player_uuid = ?");
        statement.setString(1, muted_player.getPlayerUuid());

        statement.executeUpdate();
        statement.close();
    }
}
