package lettoh.dev.controllers;

import lettoh.dev.database.Database;
import org.bukkit.entity.Player;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class WitherAdvancementController extends Database {

    public boolean playerExists(Player player) throws SQLException {
        String uuid = player.getUniqueId().toString();
        PreparedStatement statement = getConnection().prepareStatement("SELECT * from wither_advancement_players WHERE player_uuid = ?");
        statement.setString(1, uuid);

        ResultSet result = statement.executeQuery();

        return result.next();
    }

    public boolean teamHasAdvancement(ArrayList<Player> players) throws SQLException
    {
        for (Player player : players) {
            if (!playerExists(player)) return false;
        }

        return true;
    }

    public void addPlayer(Player player) throws SQLException
    {
        PreparedStatement statement = getConnection().prepareStatement("INSERT INTO wither_advancement_players VALUES(?)");
        statement.setString(1, player.getUniqueId().toString());

        statement.executeUpdate();
    }
}
