package lettoh.dev.model;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PlayerEffect {
    private Player player;

    public PlayerEffect(Player player)
    {
        this.player = player;
    }

    public void setHasteEffect()
    {
        this.player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, PotionEffect.INFINITE_DURATION, 1, false, false));
    }

    public void setWaterBreathingEffect()
    {
        this.player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, PotionEffect.INFINITE_DURATION, 0, false, false));
    }

    public void setSaturationEffect()
    {
        this.player.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION, PotionEffect.INFINITE_DURATION, 0, false, false));
    }

    public void setDamageResistanceEffect()
    {
        this.player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, PotionEffect.INFINITE_DURATION, 0, false, false));
    }

    public void setSpeedEffect()
    {
        this.player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 0, false, false));
    }
}
