package lettoh.dev.model;

public class Chronos {
    private final Integer team_id;

    public Chronos(Integer team_id)
    {
        this.team_id = team_id;
    }

    public Integer getTeamId()
    {
        return this.team_id;
    }
}
