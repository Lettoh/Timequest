package lettoh.dev.model;

public class PlayerMute {
    private String player_uuid;

    public PlayerMute(String uuid)
    {
        this.player_uuid = uuid;
    }

    public String getPlayerUuid() {
        return player_uuid;
    }
}
