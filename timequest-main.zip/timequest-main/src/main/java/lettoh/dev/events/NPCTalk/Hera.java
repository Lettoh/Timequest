package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.HeraController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionType;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Hera extends Utils {

    public void handle(Player player, TeamModel team)
    {
        HeraController hera_controller = new HeraController();

        try
        {
            if (hera_controller.hasTeamFinishedHera(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Vous avez l’air plus en forme qu’avant.");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();

                ItemStack regeneration_potion = new ItemStack(Material.POTION);
                PotionMeta potion_meta = (PotionMeta) regeneration_potion.getItemMeta();
                potion_meta.setBasePotionData(new PotionData(PotionType.REGEN, false, true));
                regeneration_potion.setItemMeta(potion_meta);

                if (player_inventory.contains(regeneration_potion))
                {
                    player.sendMessage("yen a");
                    int total = 0;
                    HashMap<Integer, ? extends ItemStack> slots = player_inventory.all(regeneration_potion);

                    for (Map.Entry<Integer, ? extends ItemStack> set : slots.entrySet()) {
                        total += set.getValue().getAmount();
                    }

                    if (total >= 15)
                    {
                        try
                        {
                            hera_controller.addHera(team.getId());

                            ItemStack regeneration_potion_to_remove = new ItemStack(Material.POTION, 15);
                            PotionMeta potion_to_remove_meta = (PotionMeta) regeneration_potion.getItemMeta();
                            potion_to_remove_meta.setBasePotionData(new PotionData(PotionType.REGEN, false, true));
                            regeneration_potion_to_remove.setItemMeta(potion_to_remove_meta);

                            player_inventory.removeItem(regeneration_potion_to_remove);

                            TeamsController team_controller = new TeamsController();
                            ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());

                            triggerHera(members, team);
                            (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                        }
                        catch (SQLException ex)
                        {
                            System.out.println("Une erreur est survenue dans l'ajout de la team "+team.getName()+" à la table hera");
                            ex.printStackTrace();
                        }
                    }
                    else
                    {
                        Utils.sendPersonalMessage(player, "Héra aimerait bien se refaire une santé.\nIl parait que 5 fournées de potion de Régénération II\nferont l’affaire.");
                    }
                }
                else
                {
                    Utils.sendPersonalMessage(player, "Héra aimerait bien se refaire une santé.\nIl parait que 5 fournées de potion de Régénération II\nferont l’affaire.");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée hera");
            ex.printStackTrace();
        }
    }

    protected void triggerHera(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Héra", team);

        for (Player player : players)
        {
            player.setMaxHealth(40);
            Utils.sendPersonalMessage(player, "C’est moi ou je ne me suis jamais\nsenti aussi vivant ?");
        }
    }
}
