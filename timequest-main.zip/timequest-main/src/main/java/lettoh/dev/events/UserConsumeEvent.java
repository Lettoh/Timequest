package lettoh.dev.events;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.potion.PotionEffect;
import java.util.Collection;

public class UserConsumeEvent implements Listener {
    @EventHandler
    public void OnUserConsume(PlayerItemConsumeEvent e) {
        Player player = e.getPlayer();

        if (e.getItem().getType().equals(Material.MILK_BUCKET))
        {
            Collection<PotionEffect> effects = player.getActivePotionEffects();

            effects.forEach(effect -> {
                if (effect.getDuration() == -1) e.setCancelled(true);
            });
        }
    }
}
