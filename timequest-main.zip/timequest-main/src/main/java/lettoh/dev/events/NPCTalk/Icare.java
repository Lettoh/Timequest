package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.IcareController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.entity.Player;

import java.sql.SQLException;
import java.util.ArrayList;

public class Icare extends Utils {

    public void handle(Player player, TeamModel team) {
        IcareController icare_controller = new IcareController();

        try {
            if (icare_controller.hasTeamFinishedIcare(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Ne va pas trop vite, tu risques de glisser dans les virages.");
            }
            else
            {
                icare_controller.addIcare(team.getId());
                TeamsController team_controller = new TeamsController();
                ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());
                triggerIcare(members, team);
            }
        } catch (SQLException ex) {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée icare");
            ex.printStackTrace();
        }
    }

    protected void triggerIcare(ArrayList<Player> players, TeamModel team) {

        for (Player player : players)
        {
            (new PlayerEffect(player)).setSpeedEffect();
            Utils.sendThinkingMessage(player, "Usain bolt ne va pas faire long feu.");
        }
    }
}
