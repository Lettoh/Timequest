package lettoh.dev.events;

import lettoh.dev.controllers.HermesController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.model.TeamModel;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

import java.sql.SQLException;
import java.util.Arrays;

public class UserFallEvent implements Listener {
    @EventHandler
    public void onUserFall(EntityDamageEvent e)
    {
        Entity entity = e.getEntity();

        if (entity instanceof Player)
        {
            Player player = (Player) entity;
            if (e.getCause().equals(EntityDamageEvent.DamageCause.FALL))
            {
                try
                {
                    TeamsController team_controller = new TeamsController();
                    TeamModel team = team_controller.findTeamByPlayer(player);

                    HermesController hermes_controller = new HermesController();

                    if (hermes_controller.hasTeamFinishedHermes(team.getId()))
                        e.setCancelled(true);
                }
                catch (SQLException ex)
                {
                    System.out.println("Erreur lors de l'annulation des dégats de chute.\n"+ Arrays.toString(player.getInventory().getContents()));
                    ex.printStackTrace();
                }
            }
        }
    }
}
