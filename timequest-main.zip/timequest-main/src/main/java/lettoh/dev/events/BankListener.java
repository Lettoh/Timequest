package lettoh.dev.events;

import eu.decentsoftware.holograms.api.DHAPI;
import eu.decentsoftware.holograms.api.holograms.Hologram;
import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.events.NPCTalk.Utils;
import lettoh.dev.model.TeamModel;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BankListener implements Listener {

    private TimeQuest plugin;

    public BankListener(TimeQuest plugin)
    {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBankClick(InventoryClickEvent e)
    {
        Player player = (Player) e.getWhoClicked();

        try
        {
            if (e.getView().getTitle().equalsIgnoreCase(ChatColor.DARK_PURPLE + "Banque"))
            {
                if (plugin.bank_disabled)
                {
                    e.setCancelled(true);
                    player.sendMessage(ChatColor.RED + "La banque est temporairement désactivée.");
                    return;
                }

                if (!(e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.LEFT))
                {
                    e.setCancelled(true);
                    player.updateInventory();
                    return;
                }
                TeamsController team_controller = new TeamsController();
                TeamModel team = team_controller.findTeamByPlayer(player);

                if (e.getCurrentItem() == null) return;

                if (e.getCurrentItem().getType() == Material.EMERALD && e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.GREEN + "Émeraude"))
                {
                    if (e.getClick() == ClickType.RIGHT)
                    {
                        sellEmerald(player, team, Material.EMERALD, 1);
                    }
                    else if (e.getClick() == ClickType.LEFT)
                    {
                        sellEmerald(player, team, Material.EMERALD, 64);
                    }
                    e.setCancelled(true);
                }
                else if (e.getCurrentItem().getType() == Material.EMERALD_BLOCK && e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.GREEN + "Bloc d'émeraude"))
                {
                    if (e.getClick() == ClickType.RIGHT)
                    {
                        sellEmerald(player, team, Material.EMERALD_BLOCK, 1);
                    }
                    else if (e.getClick() == ClickType.LEFT)
                    {
                        sellEmerald(player, team, Material.EMERALD_BLOCK, 64);
                    }
                    e.setCancelled(true);
                }

                e.setCancelled(true);
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue dans la gestion de la banque.");
            ex.printStackTrace();
        }
    }

    protected void sellEmerald(Player player, TeamModel team, Material material, Integer amount)
    {
        PlayerInventory player_inventory = player.getInventory();

        if (player_inventory.contains(material))
        {
            Integer total = 0;
            Integer to_remove = amount;
            HashMap<Integer, ? extends ItemStack> slots = player_inventory.all(material);

            for (Map.Entry<Integer, ? extends ItemStack> set : slots.entrySet())
            {
                ItemStack found = set.getValue();
                ItemMeta meta = found.getItemMeta();
                if (meta != null)
                {
                    List<String> lore = meta.getLore();
                    if (lore != null)
                    {
                        if (lore.contains("1/3") || lore.contains("2/3") || lore.contains("3/3")) continue;
                    }
                }

                total += set.getValue().getAmount();
            }

            if (total < amount) to_remove = total;

            TeamsController team_controller = new TeamsController();

            try 
            {
                Integer score = to_remove;
                if (score == 0) return;

                if (material.equals(Material.EMERALD_BLOCK)) score = to_remove * 9;

                if (plugin.zeus_teams.contains(team.getId()))
                {
                    score = (int) Math.floor(score * 1.5);
                }

                team_controller.addScore(team, Long.valueOf(score));
                player_inventory.removeItem(new ItemStack(material, to_remove));

                if (score <= 1) player.sendMessage(ChatColor.DARK_GREEN + "Vous venez d'ajouter "+ChatColor.GOLD + score + ChatColor.DARK_GREEN +" point à votre équipe.");
                else
                {
                    player.sendMessage(ChatColor.DARK_GREEN + "Vous venez d'ajouter "+ChatColor.GOLD + score + ChatColor.DARK_GREEN +" points à votre équipe.");
                    player.sendMessage(ChatColor.DARK_GRAY + "(50% bonus grâce à la bénédiction de "+ChatColor.RED+"Zeus"+ChatColor.DARK_GRAY+")");
                }
                player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_CLUSTER_STEP, 1.0F, 1.0F);

                Hologram hologram = DHAPI.getHologram("ranking");
                assert hologram != null;
                (new Utilities()).loadHologram(hologram);
            }
            catch (SQLException ex)
            {
                System.out.println("Une erreur est survenue dans l'attribution des scores de l'équipe "+team.getName());
                ex.printStackTrace();
            }
        }
    }
}
