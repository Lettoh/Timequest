package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.AphroditeController;
import lettoh.dev.controllers.ApollonController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.SQLException;
import java.util.ArrayList;

public class Aphrodite extends Utils {
    public void handle(Player player, TeamModel team)
    {
        AphroditeController aphrodite_controller = new AphroditeController();

        try
        {
            if (aphrodite_controller.hasTeamFinishedAphrodite(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Il s’agit de sa Shulker préférée. Prenez-en bien soin.");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();
                ArrayList<ItemStack> wools = getPlayerWools(player_inventory);

                if (wools.size() == 16)
                {
                    try
                    {
                        TeamsController team_controller = new TeamsController();
                        ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());
                        aphrodite_controller.addAphrodite(team.getId());
                        for (ItemStack wool : wools)
                        {
                            player_inventory.removeItem(wool);
                        }

                        triggerAphrodite(members, team);
                        (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                    }
                    catch (SQLException ex)
                    {
                        System.out.println("Une erreur est survenue dans l'ajout de l'équipe "+team.getName()+" dans la table aphrodite");
                        ex.printStackTrace();
                    }
                }
                else
                {
                    Utils.sendPersonalMessage(player, "Pour faire plaisir à Aphrodite, il vous suffit de lui montrer\n" +
                            "que votre sens de la créativité et de la beauté est\n" +
                            "bien développé.\n" +
                            "Ramenez moi donc un exemplaire de chaque coloris de laine,\n" +
                            "et Aphrodite vous montrera l’étendue de son amour.");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée hera");
            ex.printStackTrace();
        }
    }

    protected void triggerAphrodite(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Aphrodite", team);
        ItemStack shulker = new ItemStack(Material.PINK_SHULKER_BOX);

        for (Player player : players)
        {
            (new Utilities()).givePlayerItem(player, shulker);
            Utils.sendThinkingMessage(player, "Il s’agit de sa Shulker préférée. Prenez-en bien soin.");
        }
    }

    protected ArrayList<ItemStack> getPlayerWools(PlayerInventory inventory)
    {
        ArrayList<ItemStack> founded = new ArrayList<>();

        ItemStack[] storage = inventory.getStorageContents();
        for (ItemStack item : storage)
        {
            if (item == null) continue;

            if (itemIsWool(item))
            {
                ItemStack copy = item.clone();
                copy.setAmount(1);
                if (founded.contains(copy)) continue;
                founded.add(copy);

                if (founded.size() == 16) break;
            }
        }

        return founded;
    }

    protected boolean itemIsWool(ItemStack item)
    {
        ItemStack lime = new ItemStack(Material.LIME_WOOL, 1);
        ItemStack purple = new ItemStack(Material.PURPLE_WOOL, 1);
        ItemStack magenta = new ItemStack(Material.MAGENTA_WOOL, 1);
        ItemStack yellow = new ItemStack(Material.YELLOW_WOOL, 1);
        ItemStack light_blue = new ItemStack(Material.LIGHT_BLUE_WOOL, 1);
        ItemStack black = new ItemStack(Material.BLACK_WOOL, 1);
        ItemStack light_gray = new ItemStack(Material.LIGHT_GRAY_WOOL, 1);
        ItemStack brown = new ItemStack(Material.BROWN_WOOL, 1);
        ItemStack red = new ItemStack(Material.RED_WOOL, 1);
        ItemStack orange = new ItemStack(Material.ORANGE_WOOL, 1);
        ItemStack white = new ItemStack(Material.WHITE_WOOL, 1);
        ItemStack gray = new ItemStack(Material.GRAY_WOOL, 1);
        ItemStack cyan = new ItemStack(Material.CYAN_WOOL, 1);
        ItemStack blue = new ItemStack(Material.BLUE_WOOL, 1);
        ItemStack pink = new ItemStack(Material.PINK_WOOL, 1);
        ItemStack green = new ItemStack(Material.GREEN_WOOL, 1);

        return item.equals(lime)
                || item.equals(purple)
                || item.equals(magenta)
                || item.equals(yellow)
                || item.equals(light_blue)
                || item.equals(black)
                || item.equals(light_gray)
                || item.equals(brown)
                || item.equals(red)
                || item.equals(orange)
                || item.equals(white)
                || item.equals(gray)
                || item.equals(cyan)
                || item.equals(blue)
                || item.equals(pink)
                || item.equals(green);
    }
}
