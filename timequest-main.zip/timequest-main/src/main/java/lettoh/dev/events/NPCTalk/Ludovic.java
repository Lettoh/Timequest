package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.QuestController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;

public class Ludovic extends Utils {
    protected void handle(Player player, TeamModel team)
    {
        QuestController controller = new QuestController();
        try
        {
            if (controller.hasAnnexe0(team.getId()))
            {
                sendPersonalMessage(player, "Une légende raconte qu’un ancien chevalier garde un secret\ndans sa tombe.\n" +
                        "Malheureusement, celle- ci est gardée par un code !\n" +
                        "Si cette légende est vraie, le code ne devrait pas être loin de\nson caveau.\n" +
                        "Si tu veux tenter ta chance, je te souhaite bien du courage !");
            }
            else
            {
                sendPersonalMessage(player, "Une légende raconte qu’un ancien chevalier garde un secret dans sa tombe.\n" +
                        "Malheureusement, celle- ci est gardée par un code !\n" +
                        "Si cette légende est vraie, le code ne devrait pas être loin de son caveau.\n" +
                        "Si tu veux tenter ta chance, je te souhaite bien du courage !");
                controller.setAnnexe0(team.getId());
                (new Utilities()).givePlayerItem(player, new ItemStack(Material.PAPER, 1));
                (new Utilities()).givePlayerItem(player, new ItemStack(Material.EXPERIENCE_BOTTLE, 2));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}
