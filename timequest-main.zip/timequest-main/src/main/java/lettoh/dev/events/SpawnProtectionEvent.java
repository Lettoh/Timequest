package lettoh.dev.events;

import lettoh.dev.TimeQuest;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Collection;

public class SpawnProtectionEvent implements Listener {

    private final TimeQuest plugin;

    public SpawnProtectionEvent(TimeQuest plugin)
    {
        this.plugin = plugin;
    }

    @EventHandler
    public void OnBreakBloc(BlockBreakEvent e) {
        Player player = e.getPlayer();

        if (player.isOp()) return;


        if (isLocationInSpawn(e.getBlock().getLocation(), e.getBlock().getWorld()))
        {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void OnProjectileLaunch(ProjectileLaunchEvent e) {
        Entity entity = e.getEntity();

        System.out.println("ProjectileLaunchEvent" + entity.getType());

        if (entity.getType().equals(EntityType.DROPPED_ITEM)) return;
        if (entity.getType().equals(EntityType.THROWN_EXP_BOTTLE)) return;

        if (isEntityInSpawn(entity))
        {
            if (e.getEntity().getShooter() instanceof Player)
            {
                Player shooter = (Player) e.getEntity().getShooter();
                if (shooter.isOp()) return;
            }
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void OnPlayerTeleport(PlayerTeleportEvent e) {
        Player player = e.getPlayer();
        if (e.getTo() == null) return;

        if (isLocationInSpawn(e.getTo(), player.getWorld()))
        {
            if (player.isOp()) return;
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void OnPlacingBlock(BlockPlaceEvent e) {
        Player player = e.getPlayer();

        if (player.isOp()) return;

        if (isLocationInSpawn(e.getBlock().getLocation(), e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler
    public void OnEntityExplode(EntityExplodeEvent e) {
        Entity entity = e.getEntity();

        if (isEntityInSpawn(entity)) e.setCancelled(true);
    }

    @EventHandler
    public void OnEntitySpawn(EntitySpawnEvent e) {
        Entity entity = e.getEntity();

        if (entity.getType().equals(EntityType.DROPPED_ITEM)) return;
        if (entity.getType().equals(EntityType.VILLAGER)) return;
        if (entity.getType().equals(EntityType.THROWN_EXP_BOTTLE)) return;

        if (entity instanceof Player) return;

        if (isEntityInSpawn(entity)) e.setCancelled(true);
    }

    @EventHandler
    public void onPlayerDamage(EntityDamageEvent e) {
        Entity entity = e.getEntity();
        if (entity instanceof Player)
        {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void OnPlayerHit(EntityDamageByEntityEvent e) {
        Entity entity = e.getEntity();
        Entity entity_damager = e.getDamager();

        if (entity_damager instanceof Player)
        {
            Player damager = (Player) entity_damager;
            if (damager.isOp()) return;
        }

        if (isEntityInSpawn(entity))
        {
            if (entity instanceof Player || entity instanceof Villager) e.setCancelled(true);
        }
    }

    @EventHandler
    public void OnUserConsume(PlayerItemConsumeEvent e) {
        Player player = e.getPlayer();

        if (e.getItem().getType().equals(Material.CHORUS_FRUIT))
        {
            if (isEntityInSpawn(player)) e.setCancelled(true);
        }
    }

    @EventHandler
    public void onUserEmptyBucket(PlayerBucketEmptyEvent e)
    {
        if (e.getPlayer().isOp()) return;

        World world = e.getBlockClicked().getWorld();
        Location location = e.getBlockClicked().getLocation();

        if (isLocationInSpawn(location, world))
        {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onUserFillBucket(PlayerBucketFillEvent e)
    {
        if (e.getPlayer().isOp()) return;

        World world = e.getBlockClicked().getWorld();
        Location location = e.getBlockClicked().getLocation();

        if (isLocationInSpawn(location, world))
        {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onElytraFly(EntityToggleGlideEvent e)
    {
        Entity entity = e.getEntity();
        if (entity instanceof Player)
        {
            Player player = (Player) entity;
            if (player.isOp()) return;

            e.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Les elytras sont désactivées.");
        }
    }

    @EventHandler
    public void onPlaceBoat(EntityPlaceEvent e)
    {
        Entity entity = e.getEntity();
        if (entity instanceof Boat)
        {
            Player player = e.getPlayer();

            if (player != null && player.isOp()) return;

            e.setCancelled(true);
        }
    }

    protected boolean isEntityInSpawn(Entity entity)
    {
        Location entity_location = entity.getLocation();
        World world = entity_location.getWorld();

        double entity_x = entity_location.getX();
        double entity_z = entity_location.getZ();

        if (world.getName().equalsIgnoreCase("world_nether"))
        {
            return entity_z < 50 && entity_z > -20 && entity_x > 0 && entity_x < 70;
        }
        else if (world.getName().equalsIgnoreCase("world"))
        {
            if (entity_z < 230 && entity_z > 0 && entity_x > 220 && entity_x < 560) return true;
            else if (entity_z > -460 && entity_z < -330 && entity_x > 265 && entity_x < 365) return true;

            return false;
        }

        return false;
    }

    protected boolean isLocationInSpawn(Location location, World world)
    {
        double location_x = location.getX();
        double location_z = location.getZ();

        if (world.getName().equalsIgnoreCase("world_nether"))
        {

            return (location_z < 50 && location_z > -20 && location_x > 0 && location_x < 70);
        }
        else if (world.getName().equalsIgnoreCase("world"))
        {
            if (location_z < 230 && location_z > 0 && location_x > 220 && location_x < 560) return true;
            else if (location_z > -460 && location_z < -330 && location_x > 265 && location_x < 365) return true;

            return false;
        }

        return false;
    }
}
