package lettoh.dev.events;

import lettoh.dev.TimeQuest;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class UserLeaveEvent implements Listener {

    private TimeQuest plugin;

    public UserLeaveEvent(TimeQuest plugin) {
        this.plugin = plugin;
    }
    @EventHandler
    public void OnLeavePlayer(PlayerQuitEvent e) {
        Player leaver = e.getPlayer();
        if (plugin.invisible_list.contains(leaver)) return;

        e.setQuitMessage(ChatColor.AQUA + e.getPlayer().getName()+ ChatColor.GOLD +" vient de se déconnecter.");
    }
}
