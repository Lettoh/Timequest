package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.HermesController;
import lettoh.dev.model.TeamModel;
import org.bukkit.entity.Player;

import java.sql.SQLException;

public class Hermes extends Utils {
    public void handle(Player player, TeamModel team)
    {
        try
        {
            HermesController hermes_controller = new HermesController();
            if (hermes_controller.hasTeamFinishedHermes(team.getId()))
            {
                sendPersonalMessage(player, "Voilà de quoi pouvoir sauter de\ntrès haut sans se faire mal.");
            }
            else
            {
                sendPersonalMessage(player, "Selon certains, Hermès aurait laissé un coffre avec un\nparchemin et quelques babioles à la fin d’un long et\nfastidieux parcours. Je vous laisse y aller.\nPersonnellement, j’ai le vertige.");
            }
        }
        catch (SQLException e)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée hermes");
            e.printStackTrace();
        }
    }
}
