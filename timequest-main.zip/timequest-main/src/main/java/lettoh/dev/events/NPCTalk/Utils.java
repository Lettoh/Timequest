package lettoh.dev.events.NPCTalk;

import lettoh.dev.model.TeamModel;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import lettoh.dev.core.Utilities;

public class Utils {
    public static void broadcastDivinityMessage(String divinity_name, TeamModel team)
    {
        Bukkit.broadcastMessage(ChatColor.GOLD + "\nL'équipe "
                + (new Utilities()).retrieveColor(team.getColor()) + team.getName() + " ("+team.getTag()+")"
                + ChatColor.GOLD + " a reçu la Bénédiction de "
                + ChatColor.LIGHT_PURPLE + divinity_name
                + ChatColor.GOLD +"\nainsi que"
                + ChatColor.LIGHT_PURPLE + " 16"
                + ChatColor.GOLD + " Blocs d'Émeraude !"
        );

        Bukkit.getOnlinePlayers().forEach(player -> {
            player.playSound(player.getLocation(), Sound.ITEM_GOAT_HORN_SOUND_7, 1.0F, 1.0F);
        });
    }

    public static void sendPersonalMessage(Player player, String message)
    {
        player.sendMessage("\n" + ChatColor.DARK_GREEN + message+"\n\n");
    }

    public static void sendThinkingMessage(Player player, String message)
    {
        player.sendMessage("\n" + ChatColor.ITALIC + ChatColor.DARK_GRAY + message+"\n\n");
    }
}
