package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.ApollonController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.SQLException;
import java.util.ArrayList;

public class Apollon extends Utils {

    public void handle(Player player, TeamModel team)
    {
        ApollonController apollon_controller = new ApollonController();

        try
        {
            if (apollon_controller.hasTeamFinishedApollon(team.getId()))
            {
                Utils.sendPersonalMessage(player, "L’immortalité, pas mal hein…");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();
                ArrayList<ItemStack> cds = getPlayerCDs(player_inventory);

                if (cds.size() >= 10)
                {
                    try
                    {
                        TeamsController team_controller = new TeamsController();
                        ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());
                        apollon_controller.addApollon(team.getId());
                        for (ItemStack cd : cds)
                        {
                            player_inventory.removeItem(cd);
                        }

                        triggerApollon(members, team);
                        (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                    }
                    catch (SQLException ex)
                    {
                        System.out.println("Une erreur est survenue dans l'ajout de l'équipe "+team.getName()+" dans la table apollon");
                        ex.printStackTrace();
                    }
                }
                else
                {
                    Utils.sendPersonalMessage(player, "Pour son plaisir, Apollon aimerait bien se détendre en\nagrandissant sa bibliothèque de musique.\nJe pense qu’une dizaine d'œuvres musicales différentes\npourrait le satisfaire.");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée hera");
            ex.printStackTrace();
        }
    }

    protected void triggerApollon(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Apollon", team);

        for (Player player : players)
        {
            Utils.sendPersonalMessage(player, "Attendez une minute, ça donnerait quoi si je rajoutais\nune émeraude dans chaque coin quand je craft une boussole ?");
        }
    }

    protected ArrayList<ItemStack> getPlayerCDs(PlayerInventory inventory)
    {
        ArrayList<ItemStack> founded = new ArrayList<>();

        ItemStack[] storage = inventory.getStorageContents();
        for (ItemStack item : storage)
        {
            if (item == null) continue;

            if (itemIsCD(item))
            {
                if (founded.contains(item)) continue;
                founded.add(item);

                if (founded.size() == 10) break;
            }
        }

        return founded;
    }

    protected boolean itemIsCD(ItemStack item)
    {
        ItemStack ward = new ItemStack(Material.MUSIC_DISC_WARD, 1);
        ItemStack stal = new ItemStack(Material.MUSIC_DISC_STAL, 1);
        ItemStack mellohi = new ItemStack(Material.MUSIC_DISC_MELLOHI, 1);
        ItemStack mall = new ItemStack(Material.MUSIC_DISC_MALL, 1);
        ItemStack far = new ItemStack(Material.MUSIC_DISC_FAR, 1);
        ItemStack chirp = new ItemStack(Material.MUSIC_DISC_CHIRP, 1);
        ItemStack cat = new ItemStack(Material.MUSIC_DISC_CAT, 1);
        ItemStack blocks = new ItemStack(Material.MUSIC_DISC_BLOCKS, 1);
        ItemStack wait = new ItemStack(Material.MUSIC_DISC_WAIT, 1);
        ItemStack thirteen = new ItemStack(Material.MUSIC_DISC_13, 1);
        ItemStack eleven = new ItemStack(Material.MUSIC_DISC_11, 1);
        ItemStack strad = new ItemStack(Material.MUSIC_DISC_STRAD, 1);
        ItemStack otherside = new ItemStack(Material.MUSIC_DISC_OTHERSIDE, 1);
        ItemStack pigstep = new ItemStack(Material.MUSIC_DISC_PIGSTEP, 1);
        ItemStack five = new ItemStack(Material.MUSIC_DISC_5, 1);

        return item.equals(ward)
                || item.equals(stal)
                || item.equals(mellohi)
                || item.equals(mall)
                || item.equals(far)
                || item.equals(chirp)
                || item.equals(cat)
                || item.equals(blocks)
                || item.equals(wait)
                || item.equals(thirteen)
                || item.equals(eleven)
                || item.equals(strad)
                || item.equals(otherside)
                || item.equals(pigstep)
                || item.equals(five);
    }
}
