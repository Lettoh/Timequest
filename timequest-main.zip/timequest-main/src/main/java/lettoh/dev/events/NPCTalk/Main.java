package lettoh.dev.events.NPCTalk;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.model.TeamModel;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;

import java.sql.SQLException;

public class Main implements Listener {

    private TimeQuest plugin;

    public Main(TimeQuest plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void OnNPCTalk(PlayerInteractEntityEvent e) {
        Player player = e.getPlayer();
        Entity entity = e.getRightClicked();

        if (entity.getType().toString().equals("VILLAGER"))
        {
            if (player.isOp()) {
                player.sendMessage(entity.getLocation().toString());
            }

            this.handleNPC(entity.getLocation(), player);
        }
    }

    protected void handleNPC(Location location, Player player) {

        World world = plugin.getServer().getWorld("world");

        Location poseidon = new Location(world,331.5, 26.5, 125.5);
        Location chronos = new Location(world, 316.5, 29.5, 115.5);
        Location hephaistos = new Location(world,303.5, 31.5, 110.5);
        Location hermes = new Location(world,286.5, 31.5, 122.5);
        Location icare = new Location(world,258.5, 30.5, 134.5);
        Location ares = new Location(world,272.5, 26.5, 146.5);
        Location athena = new Location(world,272.5, 26.5, 150.5);
        Location hera = new Location(world,286.5, 28.5, 161.5);
        Location apollon = new Location(world,294.5, 27.5, 170.5);
        Location ploutos = new Location(world,304.5, 26.5, 172.5);
        Location aphrodite = new Location(world, 317.5, 29.0, 169.5);
        Location artemis = new Location(world,326.5, 26.5, 156.5);
        Location zeus = new Location(world, 334.5, 26.5, 142.5);
        Location ulysse = new Location(world,352.5, 68.5, 195.5);
        Location jeanmi = new Location(world,352.5, 101.0, 172.5);

        Location ludovic = new Location(world,351.5, 64.5, 104.5);
        Location francois = new Location(world,413.5, 53.0, 83.5);
        Location jeanne = new Location(world,469.5, 64.0, 73.5);

        try
        {
            TeamsController team_controller = new TeamsController();
            TeamModel team = team_controller.findTeamByPlayer(player);

            if (team == null)
            {
                player.sendMessage(ChatColor.RED + "Tu n'appartiens à aucune équipe, mp un modo.");
                return;
            }

            if (this.compareLocation(location, chronos)) (new Chronos()).handle(player, team);
            if (this.compareLocation(location, ulysse)) (new Ulysse()).handle(player);
            if (this.compareLocation(location, jeanmi)) (new JeanMi()).handle(player, team);
            if (this.compareLocation(location, hermes)) (new Hermes()).handle(player, team);
            if (this.compareLocation(location, ares)) (new Ares()).handle(player, team);
            if (this.compareLocation(location, athena)) (new Athena()).handle(player, team);
            if (this.compareLocation(location, hera)) (new Hera()).handle(player, team);
            if (this.compareLocation(location, apollon)) (new Apollon()).handle(player, team);
            if (this.compareLocation(location, poseidon)) (new Poseidon()).handle(player, team);
            if (this.compareLocation(location, artemis)) (new Artemis()).handle(player, team);
            if (this.compareLocation(location, hephaistos)) (new Hephaistos()).handle(player, team);
            if (this.compareLocation(location, ploutos)) (new Ploutos()).handle(player, team);
            if (this.compareLocation(location, icare)) (new Icare()).handle(player, team);
            if (this.compareLocation(location, aphrodite)) (new Aphrodite()).handle(player, team);
            if (this.compareLocation(location, zeus)) (new Zeus(plugin)).handle(player, team);

            if (this.compareLocation(location, ludovic)) (new Ludovic()).handle(player, team);
            if (this.compareLocation(location, francois)) (new Francois()).handle(player, team);
            if (this.compareLocation(location, jeanne)) (new Jeanne()).handle(player, team);
        }
        catch (SQLException e)
        {
            System.out.println("Une erreur est survenue dans la récupération de l'équipe du joueur. NPCTalk/Main.java");
            e.printStackTrace();
        }
    }

    protected Boolean compareLocation(Location location_1, Location location_2) {
        return location_1.getX() == location_2.getX()
            && location_1.getY() == location_2.getY()
            && location_1.getZ() == location_2.getZ();
    }
}
