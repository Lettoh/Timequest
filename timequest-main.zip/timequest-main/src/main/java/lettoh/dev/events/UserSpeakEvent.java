package lettoh.dev.events;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.PlayerMuteController;
import lettoh.dev.model.PlayerMute;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.sql.SQLException;

public class UserSpeakEvent implements Listener {

    private TimeQuest plugin;

    public UserSpeakEvent(TimeQuest plugin) {
        this.plugin = plugin;
    }
    @EventHandler
    public void OnPlayerSpeak(AsyncPlayerChatEvent e) {
        Player player = e.getPlayer();
        PlayerMuteController controller = new PlayerMuteController();

        try
        {
            PlayerMute muted_player = controller.findMutedPlayerByUUID(player.getUniqueId().toString());
            if (plugin.chat_disabled){
                if (!player.isOp()) {
                    e.setCancelled(true);
                    player.sendMessage(ChatColor.RED+"Le chat est mute.");
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_HURT, 1.0F, 1.0F);
                }
            }
            else if (muted_player != null) {
                e.setCancelled(true);
                player.sendMessage(ChatColor.RED+"Tu es mute.");
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_HURT, 1.0F, 1.0F);
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue sur l'event UserSpeakEvent.");
            ex.printStackTrace();
        }
    }
}
