package lettoh.dev.events.NPCTalk;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.*;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.sql.SQLException;
import java.util.ArrayList;

public class Zeus extends Utils {

    private TimeQuest plugin;

    public Zeus(TimeQuest plugin)
    {
        this.plugin = plugin;
    }
    public void handle(Player player, TeamModel team) {
        ZeusController zeusController = new ZeusController();
        try
        {
            if (zeusController.hasTeamFinishedZeus(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Fais bon usage de tous les savoirs que tu as acquéris.\n");
            }
            else
            {
                boolean check = hasTeamAllBenedictions(team);

                if (!check)
                {
                    sendPersonalMessage(player, "Tant que vous n’avez pas triomphé des épreuves de\nchacun de mes enfants, je ne pourrais rien faire pour vous.");
                    return;
                }

                TeamsController team_controller = new TeamsController();
                ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());

                zeusController.addZeus(team.getId());
                plugin.zeus_teams.add(team.getId());
                triggerZeus(members, team);
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée icare");
            ex.printStackTrace();
        }
    }

    protected boolean hasTeamAllBenedictions(TeamModel team)
    {
        AphroditeController aphrodite_controller = new AphroditeController();
        ApollonController apollon_controller = new ApollonController();
        AresController ares_controller = new AresController();
        ArtemisController artemis_controller = new ArtemisController();
        AthenaController athena_controller = new AthenaController();
        ChronosController chronos_controller = new ChronosController();
        HephaistosController hephaistos_controller = new HephaistosController();
        HeraController hera_controller = new HeraController();
        HermesController hermes_controller = new HermesController();
        PloutosController ploutos_controller = new PloutosController();
        PoseidonController poseidon_controller = new PoseidonController();

        try
        {
            if (!aphrodite_controller.hasTeamFinishedAphrodite(team.getId())) return false;
            if (!apollon_controller.hasTeamFinishedApollon(team.getId())) return false;
            if (!ares_controller.hasTeamFinishedAres(team.getId())) return false;
            if (!artemis_controller.hasTeamFinishedArtemis(team.getId())) return false;
            if (!athena_controller.hasTeamFinishedAthena(team.getId())) return false;
            if (!chronos_controller.hasTeamFinishedChronos(team.getId())) return false;
            if (!hephaistos_controller.hasTeamFinishedHephaistos(team.getId())) return false;
            if (!hera_controller.hasTeamFinishedHera(team.getId())) return false;
            if (!hermes_controller.hasTeamFinishedHermes(team.getId())) return false;
            if (!ploutos_controller.hasTeamFinishedPloutos(team.getId())) return false;
            if (!poseidon_controller.hasTeamFinishedPoseidon(team.getId())) return false;

        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de la vérification des bénédictions pour Zeus");
            ex.printStackTrace();
        }

        return true;
    }

    protected void triggerZeus(ArrayList<Player> players, TeamModel team)
    {
        Bukkit.broadcastMessage(ChatColor.DARK_GRAY + "\nL'équipe "
                + (new Utilities()).retrieveColor(team.getColor()) + team.getName() + " ("+team.getTag()+")"
                + ChatColor.DARK_GRAY + " a reçu la Bénédiction de "
                + ChatColor.RED + "Zeus"
                + ChatColor.DARK_GRAY +"\nainsi que"
                + ChatColor.RED + " 16"
                + ChatColor.DARK_GRAY + " Blocs d'Émeraude !"
        );

        Bukkit.getOnlinePlayers().forEach(player -> {
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
        });

        for (Player player : players)
        {
            (new PlayerEffect(player)).setSpeedEffect();
            Utils.sendThinkingMessage(player, "Usain bolt ne va pas faire long feu.");
        }
    }
}
