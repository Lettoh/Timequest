package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.ChronosController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.controllers.WitherAdvancementController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;

import java.sql.SQLException;
import java.util.ArrayList;

public class
Chronos extends Utils implements Listener {
    public void handle(Player player, TeamModel team) {
        ChronosController chronos_controller = new ChronosController();

        try
        {
            TeamsController team_controller = new TeamsController();

            Boolean team_has_chronos = chronos_controller.hasTeamFinishedChronos(team.getId());

            if (team_has_chronos)
            {
                Utils.sendPersonalMessage(player, "Alors, toutes les pioches paraissent plus puissantes" +
                        "\nmaintenant hein ?");
            }
            else
            {
                ArrayList<Player> team_players = team_controller.findPlayersByTeam(team.getId());
                WitherAdvancementController wither_advancement_controller = new WitherAdvancementController();
                if (wither_advancement_controller.teamHasAdvancement(team_players))
                {
                    chronos_controller.addChronos(team.getId());
                    triggerChronos(team_players, team);
                    (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                }
                else
                {
                    Utils.sendPersonalMessage(player, "Votre destinée sera d’invoquer, avec ton équipe au complet," +
                            "\ndans les plus bref délais, ce que jadis certains nommaient" +
                            "\nle dragon de l’enfer." +
                            "\nReviens vers moi quand ce sera fait.");
                }
            }
        }
        catch (SQLException e)
        {
            System.out.println("Une erreur est survenue dans l'attribution de l'effet Haste II pour l'équipe X"); //Todo: Remplacer X par le nom d'équipe
            e.printStackTrace();
        }
    }

    protected void triggerChronos(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Chronos", team);
        System.out.println(players);

        for (Player player : players)
        {
            (new PlayerEffect(player)).setHasteEffect();

            Utils.sendPersonalMessage(player, "J'ai l'impression d'être devenu mineur professionnel...");
        }
    }

    @EventHandler
    public void OnWitherDone(PlayerAdvancementDoneEvent e) {
        Player player = e.getPlayer();
        String advancement = e.getAdvancement().getKey().getKey();
        System.out.println(advancement);

        if (advancement.equals("nether/summon_wither"))
        {
            try
            {
                WitherAdvancementController wither_advancement_controller = new WitherAdvancementController();
                wither_advancement_controller.addPlayer(player);
            }
            catch (SQLException ex)
            {
                System.out.println("Une erreur est survenue lors de l'ajout du joueur "+ player.getUniqueId() +" dans la base de donnée wither_advancement_players");
                ex.printStackTrace();
            }
        }
    }
}
