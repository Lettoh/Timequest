package lettoh.dev.events;

import lettoh.dev.controllers.ApollonController;
import lettoh.dev.controllers.AthenaController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.events.NPCTalk.Utils;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;

import java.sql.SQLException;

public class UserCraftEvent extends Utils implements Listener {
    @EventHandler
    public void OnUserCraft(PrepareItemCraftEvent e)
    {
        Recipe recipe = e.getRecipe();
        if (recipe == null) return;

        for (HumanEntity human : e.getViewers())
        {
            if (human instanceof Player)
            {
                Player player = (Player) human;
                ItemStack result = recipe.getResult();

                if (result.equals(new ItemStack(Material.EXPERIENCE_BOTTLE, 6)))
                {
                    try
                    {
                        TeamsController team_controller = new TeamsController();
                        TeamModel team = team_controller.findTeamByPlayer(player);
                        AthenaController athena_controller = new AthenaController();
                        if (!(athena_controller.hasTeamFinishedAthena(team.getId())))
                        {
                            e.getInventory().setResult(new ItemStack(Material.AIR));
                        }
                    }
                    catch (SQLException ex)
                    {
                        e.getInventory().setResult(new ItemStack(Material.AIR));
                        System.out.println("Une erreur est survenue lors du craft de la bouteille d'xp.");
                        ex.printStackTrace();
                    }
                }
                else if (result.equals(new ItemStack(Material.TOTEM_OF_UNDYING, 1)))
                {
                    try
                    {
                        TeamsController team_controller = new TeamsController();
                        TeamModel team = team_controller.findTeamByPlayer(player);
                        ApollonController apollon_controller = new ApollonController();
                        if (!(apollon_controller.hasTeamFinishedApollon(team.getId())))
                        {
                            e.getInventory().setResult(new ItemStack(Material.AIR));
                        }
                    }
                    catch (SQLException ex)
                    {
                        System.out.println("Une erreur est survenue lors du craft du totem of undying.");
                        ex.printStackTrace();
                    }
                }
            }
        }
    }
}
