package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.HephaistosController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

public class Hephaistos extends Utils {
    public void handle(Player player, TeamModel team)
    {
        HephaistosController hephaistos_controller = new HephaistosController();

        try
        {
            if (hephaistos_controller.hasTeamFinishedHephaistos(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Je suppose qu'une pichenette sur le nez ne vous fait\nplus mal désormais.");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();
                ArrayList<ItemStack> hephaistos_armor = getHephaistosArmor(player_inventory);

                if (hephaistos_armor.size() == 4)
                {
                    try
                    {
                        TeamsController team_controller = new TeamsController();
                        ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());
                        hephaistos_controller.addHephaistos(team.getId());

                        for (ItemStack armor : hephaistos_armor)
                        {
                            player_inventory.removeItem(new ItemStack(armor));
                        }

                        triggerHephaistos(members, team);
                        (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                    }
                    catch (SQLException ex)
                    {
                        System.out.println("Une erreur est survenue dans l'ajout de l'équipe "+team.getName()+" dans la table hephaistos");
                        ex.printStackTrace();
                    }
                }
                else
                {
                    Utils.sendPersonalMessage(player, "Le diamant vous devrez manier, l'armure entière vous devrez\nme ramener.\n" +
                            "De Protection IV, Unbreaking III, elle devra être forgée\n" +
                            "pour espérer être récompensé.");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée hephaistos");
            ex.printStackTrace();
        }
    }

    protected void triggerHephaistos(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Héphaïstos", team);

        for (Player player : players)
        {
            (new PlayerEffect(player)).setDamageResistanceEffect();
            Utils.sendPersonalMessage(player, "Vous vous sentez plus résistant.");
        }
    }

    protected ArrayList<ItemStack> getHephaistosArmor(PlayerInventory inventory)
    {
        ArrayList<ItemStack> armors = new ArrayList<>();

        ItemStack helmet = getRequiredEnchanted(inventory, Material.DIAMOND_HELMET);
        ItemStack chestplate = getRequiredEnchanted(inventory, Material.DIAMOND_CHESTPLATE);
        ItemStack leggings = getRequiredEnchanted(inventory, Material.DIAMOND_LEGGINGS);
        ItemStack boots = getRequiredEnchanted(inventory, Material.DIAMOND_BOOTS);

        if (helmet != null) armors.add(helmet);
        if (chestplate != null) armors.add(chestplate);
        if (leggings != null) armors.add(leggings);
        if (boots != null) armors.add(boots);

        return armors;
    }

    protected ItemStack getRequiredEnchanted(PlayerInventory inventory, Material material)
    {
        boolean found_protection = false;
        boolean found_unbreaking = false;

        ItemStack[] storage = inventory.getStorageContents();
        for (ItemStack item : storage)
        {
            if (item == null) continue;

            if (item.getType().equals(material))
            {
                Map<Enchantment, Integer> enchants = item.getEnchantments();
                for (Map.Entry<Enchantment, Integer> set : enchants.entrySet())
                {
                    System.out.println(set.getKey().getKey().getKey());
                    if (set.getKey().getKey().getKey().equals("protection") && set.getValue() == 4) found_protection = true;
                    if (set.getKey().getKey().getKey().equals("unbreaking") && set.getValue() == 3) found_unbreaking = true;
                }

                if (found_protection && found_unbreaking) return item;
            }
        }
        return null;
    }
}
