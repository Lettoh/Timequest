package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.AresController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.checkerframework.checker.units.qual.A;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Ares extends Utils {
    public void handle(Player player, TeamModel team)
    {
        AresController ares_controller = new AresController();

        try
        {
            if (ares_controller.hasTeamFinishedAres(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Vous pouvez l’utiliser pour couper vos tomates,\nça fonctionne pas mal.");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();

                if (player_inventory.contains(Material.DIAMOND))
                {
                    int total = 0;
                    HashMap<Integer, ? extends ItemStack> slots = player_inventory.all(Material.DIAMOND);

                    for (Map.Entry<Integer, ? extends ItemStack> set : slots.entrySet()) {
                        total += set.getValue().getAmount();
                    }

                    if (total >= 64)
                    {
                        try
                        {
                            ares_controller.addAres(team.getId());
                            player_inventory.removeItem(new ItemStack(Material.DIAMOND, 64));

                            TeamsController team_controller = new TeamsController();
                            ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());

                            triggerAres(members, team);
                            ItemStack ares_sword = new ItemStack(Material.NETHERITE_SWORD);
                            ares_sword.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 7);
                            ares_sword.addUnsafeEnchantment(Enchantment.LOOT_BONUS_MOBS, 3);
                            ItemMeta ares_sword_meta = ares_sword.getItemMeta();
                            ares_sword_meta.setDisplayName(ChatColor.RED + "Épée sacrée d'Arès");
                            ares_sword_meta.setUnbreakable(true);
                            ares_sword.setItemMeta(ares_sword_meta);

                            (new Utilities()).givePlayerItem(player, ares_sword);
                            (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                        }
                        catch (SQLException ex)
                        {
                            System.out.println("Une erreur est survenue dans l'ajout de la team "+team.getName()+" à la table ares");
                            ex.printStackTrace();
                        }
                    }
                    else
                    {
                        Utils.sendPersonalMessage(player, "Arès voudrait partir en guerre mais malheureusement,\nil n'a pas de quoi batailler. Je pense qu’un stack de diamant\ndevrait suffir pour qu’il puisse s’amuser un minimum.");
                    }
                }
                else
                {
                    Utils.sendPersonalMessage(player, "Arès voudrait partir en guerre mais malheureusement,\nil n'a pas de quoi batailler. Je pense qu’un stack de diamant\ndevrait suffir pour qu’il puisse s’amuser un minimum.");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée ares");
            ex.printStackTrace();
        }
    }

    protected void triggerAres(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Arès", team);

        for (Player player : players)
        {
            Utils.sendPersonalMessage(player, "Ça a l’air de bien couper.");
        }
    }
}
