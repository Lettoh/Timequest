package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.HermesController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import java.sql.SQLException;
import java.util.ArrayList;

public class JeanMi extends Utils implements Listener {

    public void handle(Player player, TeamModel team)
    {
        HermesController controller = new HermesController();
        try
        {
            if (controller.hasTeamFinishedHermes(team.getId())) return;
            TeamsController team_controller = new TeamsController();
            ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());

            controller.addHermes(team.getId());
            triggerHermes(members, team);
            (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
        }
        catch (SQLException e)
        {
            System.out.println("Une erreur est survenue dans l'ajout de l'utilisateur "+player.getUniqueId()+" dans la base de donnée Jump");
            e.printStackTrace();
        }
    }

    protected void triggerHermes(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Hermès", team);

        for (Player player : players)
        {
            Utils.sendPersonalMessage(player, "Mes genoux ? Cassés ? Plus jamais.");
        }
    }
}
