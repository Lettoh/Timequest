package lettoh.dev.events;

import lettoh.dev.TimeQuest;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class UserJoinEvent implements Listener {

    private TimeQuest plugin;

    public UserJoinEvent(TimeQuest plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void OnPlayerJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();

        if (plugin.invisible_list.contains(player)) return;

        e.setJoinMessage(ChatColor.AQUA + e.getPlayer().getName()+ ChatColor.GOLD +" vient de se connecter.");
        for (int i = 0; i < plugin.invisible_list.size(); i++) {
            player.hidePlayer(plugin, plugin.invisible_list.get(i));
        }
    }
}
