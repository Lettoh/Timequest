package lettoh.dev.events;

import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;

public class DisableElytraEvent implements Listener {
    @EventHandler
    public void OnClickItemFrame(EntityDamageByEntityEvent e)
    {
        Entity entity = e.getEntity();
        Entity damager = e.getDamager();

        if (entity.getWorld().getName().equalsIgnoreCase("world_the_end"))
        {
            if (damager instanceof Player)
            {
                Player d = (Player) damager;
                if (d.isOp()) return;
            }

            if (entity instanceof ItemFrame)
            {
                damager.sendMessage(ChatColor.RED + "Les elytras sont désactivées.");
                e.setCancelled(true);
            }
        }

    }

    @EventHandler
    public void OnItemFrameBreaking(HangingBreakEvent e)
    {
        Entity entity = e.getEntity();

        if (entity.getWorld().getName().equalsIgnoreCase("world_the_end"))
        {
            if (entity instanceof ItemFrame)
            {
                e.setCancelled(true);
            }
        }
    }
}
