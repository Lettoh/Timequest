package lettoh.dev.events;

import lettoh.dev.TimeQuest;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.EndPortalFrame;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;

public class PreventEndPortalCreationEvent implements Listener {
    private final TimeQuest plugin;
    public PreventEndPortalCreationEvent(TimeQuest plugin)
    {
        this.plugin = plugin;
    }
    @EventHandler
    public void OnPortalCreation(BlockPlaceEvent e)
    {
        Block placed = e.getBlockPlaced();
        if (e.getPlayer().isOp()) return;
        if (!placed.getType().equals(Material.END_PORTAL_FRAME)) return;

        EndPortalFrame frame = (EndPortalFrame) placed.getBlockData();
        System.out.println(frame.hasEye());

        if (!(plugin.end_enabled))
        {
            if (frame.hasEye()) {
                e.getPlayer().sendMessage(ChatColor.RED + "L'end est désactivé.");
                e.setCancelled(true);
            }
        }
    }
}
