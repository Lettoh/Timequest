package lettoh.dev.events.NPCTalk;

import lettoh.dev.TimeQuest;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

public class Ulysse extends Utils {
    public void handle(Player player)
    {
        openUlysseInventory(player);
    }

    protected void openUlysseInventory(Player player)
    {
        Inventory inventory = Bukkit.createInventory(player, 9, ChatColor.DARK_PURPLE + "Banque");

        ItemStack emerald = new ItemStack(Material.EMERALD, 1);
        ItemMeta emerald_meta = emerald.getItemMeta();
        emerald_meta.setDisplayName(ChatColor.GREEN + "Émeraude");
        ArrayList<String> emerald_lore = new ArrayList<>();
        emerald_lore.add(ChatColor.LIGHT_PURPLE+"Clique gauche pour vendre par stack.");
        emerald_lore.add(ChatColor.LIGHT_PURPLE+"Clique droit pour vendre par unité.");
        emerald_meta.setLore(emerald_lore);
        emerald.setItemMeta(emerald_meta);

        ItemStack emerald_block = new ItemStack(Material.EMERALD_BLOCK, 1);
        ItemMeta emerald_block_meta = emerald_block.getItemMeta();
        emerald_block_meta.setDisplayName(ChatColor.GREEN + "Bloc d'émeraude");
        ArrayList<String> emerald_bloc_lore = new ArrayList<>();
        emerald_bloc_lore.add(ChatColor.LIGHT_PURPLE+"Clique gauche pôur vendre par stack.");
        emerald_bloc_lore.add(ChatColor.LIGHT_PURPLE+"Clique droit pour vendre par unité.");
        emerald_block_meta.setLore(emerald_bloc_lore);
        emerald_block.setItemMeta(emerald_block_meta);

        inventory.setItem(0, emerald);
        inventory.setItem(1, emerald_block);

        player.openInventory(inventory);
    }
}
