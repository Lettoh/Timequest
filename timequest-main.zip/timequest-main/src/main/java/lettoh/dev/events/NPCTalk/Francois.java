package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.QuestController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;

public class Francois extends Utils {
    protected void handle(Player player, TeamModel team)
    {
        QuestController controller = new QuestController();
        try
        {
            if (!controller.hasAnnexe0(team.getId())) return;

            if (controller.hasAnnexe1(team.getId()))
            {
                sendPersonalMessage(player, "Hm… tu m’as retrouvé. Fort bien, jeune aventurier.\n" +
                        "Mais ton périple est loin d’être terminé !\n" +
                        "A l’époque, si l’on avait eu la vision sur l’entièreté\n" +
                        "de l’horizon " +
                        "on aurait pu prévenir et les voir venir.\n" +
                        "Jeanne saura quoi en faire.");
            }
            else
            {
                sendPersonalMessage(player, "Hm… tu m’as retrouvé. Fort bien, jeune aventurier.\n" +
                        "Mais ton périple est loin d’être terminé !\n" +
                        "A l’époque, si l’on avait eu la vision sur l’entièreté de l’horizon, \n" +
                        "on aurait pu prévenir et les voir venir.\n" +
                        "Jeanne saura quoi en faire.");

                controller.setAnnexe1(team.getId());

                sendPersonalMessage(player, "Jeanne ? La guetteuse ? Elle devrait être facile à trouver.");
                ItemStack reward = new ItemStack(Material.ENDER_EYE);
                ItemMeta meta = reward.getItemMeta();
                meta.setDisplayName(ChatColor.GOLD + "Œil de sauron");
                reward.setItemMeta(meta);

                (new Utilities()).givePlayerItem(player, reward);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}
