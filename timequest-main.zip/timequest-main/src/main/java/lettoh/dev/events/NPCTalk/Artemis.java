package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.ArtemisController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Artemis extends Utils {

    public void handle(Player player, TeamModel team)
    {
        ArtemisController artemis_controller = new ArtemisController();

        try
        {
            if (artemis_controller.hasTeamFinishedArtemis(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Le banquet d'Artémis se déroulera sans encombre grâce à\nvotre aide.\nVous devriez lâchez cette viande de zombie excécrâble,\nvous n’en avez plus besoin.");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();

                if (hasArtemisRequirements(player_inventory))
                {
                    try
                    {
                        TeamsController team_controller = new TeamsController();
                        ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());
                        artemis_controller.addArtemis(team.getId());

                        player_inventory.removeItem(new ItemStack(Material.COOKED_RABBIT, 16));
                        player_inventory.removeItem(new ItemStack(Material.COOKED_CHICKEN, 32));
                        player_inventory.removeItem(new ItemStack(Material.COOKED_PORKCHOP, 64));
                        player_inventory.removeItem(new ItemStack(Material.COOKED_MUTTON, 64));
                        player_inventory.removeItem(new ItemStack(Material.COOKED_BEEF, 64));

                        triggerArtemis(members, team);
                        (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                    }
                    catch (SQLException ex)
                    {
                        System.out.println("Une erreur est survenue dans l'ajout de l'équipe "+team.getName()+" dans la table hephaistos");
                        ex.printStackTrace();
                    }
                }
                else
                {
                    sendPersonalMessage(player, "Je déclare la chasse ouverte !\n" +
                            "Pour se sustenter, Artémis aurait bien besoin de\n" +
                            "quelques victuailles. Soit l’équivalent d’un stack de cochonou,\n" +
                            "de vache et de moutons. Ainsi que 32 poulets et 16 lapins.\n" +
                            "Tout ça bien cuit, évidemment.\n" +
                            "Cela devrait aisément faire l’affaire pour tenir 3 jours !");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée hephaistos");
            ex.printStackTrace();
        }
    }

    protected void triggerArtemis(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Artémis", team);

        for (Player player : players)
        {
            (new PlayerEffect(player)).setSaturationEffect();
            Utils.sendPersonalMessage(player, "Vous sentez la sensation de faim disparaître.");
        }
    }

    protected boolean hasArtemisRequirements(PlayerInventory inventory)
    {
        if (!hasEnough(Material.COOKED_BEEF, 64, inventory)) return false;
        if (!hasEnough(Material.COOKED_CHICKEN, 32, inventory)) return false;
        if (!hasEnough(Material.COOKED_MUTTON, 64, inventory)) return false;
        if (!hasEnough(Material.COOKED_PORKCHOP, 64, inventory)) return false;
        if (!hasEnough(Material.COOKED_RABBIT, 16, inventory)) return false;

        return true;
    }

    protected boolean hasEnough(Material material, int amount, Inventory inventory)
    {
        int total = 0;
        HashMap<Integer, ? extends ItemStack> slots = inventory.all(material);

        for (Map.Entry<Integer, ? extends ItemStack> set : slots.entrySet()) {
            total += set.getValue().getAmount();
        }

        return total >= amount;
    }
}
