package lettoh.dev.events;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Openable;
import org.bukkit.block.data.type.Door;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.MaterialData;

import java.util.Objects;

public class InteractEvent implements Listener {
    @EventHandler
    public void OnPlayerInteract(PlayerInteractEvent e)
    {
        Block block = e.getClickedBlock();
        if (block == null) return;

        if (block.getType().equals(Material.IRON_DOOR))
        {
            if (e.getAction().equals(Action.RIGHT_CLICK_BLOCK) && e.getHand().equals(EquipmentSlot.OFF_HAND))
            {
                Location grave_location = new Location(Bukkit.getWorld("world"), 406, 64, 83);
                Location grave_location_2 = new Location(Bukkit.getWorld("world"), 406, 65, 83);
                if (block.getLocation().equals(grave_location) || block.getLocation().equals(grave_location_2))
                {
                    Player player = e.getPlayer();
                    ItemStack[] storage = player.getInventory().getStorageContents();
                    for (ItemStack item : storage)
                    {
                        if (item == null) continue;

                        if (item.getType().equals(Material.PAPER))
                        {
                            if (Objects.requireNonNull(item.getItemMeta()).getDisplayName().equalsIgnoreCase("SOS"))
                            {
                                player.teleport(new Location(Bukkit.getWorld("world"), 407.5, 64, 83.5, -90, 0));
                                break;
                            }
                        }

                    }
                }
            }
        }
    }
}
