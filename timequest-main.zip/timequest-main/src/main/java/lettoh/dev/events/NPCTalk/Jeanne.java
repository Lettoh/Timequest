package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.QuestController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;

public class Jeanne extends Utils {
    protected void handle(Player player, TeamModel team)
    {
        QuestController controller = new QuestController();
        try
        {
            if (!controller.hasAnnexe1(team.getId())) return;

            boolean found = false;
            ItemStack sauron = new ItemStack(Material.ENDER_EYE);
            ItemMeta meta = sauron.getItemMeta();
            meta.setDisplayName(ChatColor.GOLD + "Œil de sauron");
            sauron.setItemMeta(meta);

            ItemStack[] storage = player.getInventory().getStorageContents();
            for (ItemStack item : storage)
            {
                if (item == null) continue;
                if (item.equals(sauron))
                {
                    found = true;
                    break;
                }
            }

            if (!found) return;

            if (controller.hasAnnexe2(team.getId()))
            {
                sendPersonalMessage(player, "Oh te voilà enfin !\n"+
                        "Malheureusement, il est trop tard. Mon frère est déjà parti\n" +
                        "se réfugier dans les profondeurs. J'espère qu’il ne s'est pas\nperdu…\n" +
                        "Laisse moi donc l'œil, que je puisse prévenir d’un futur\nassaut.\n" +
                        "Et ramène ça à mon frère, il l’a oublié en partant.");

                sendPersonalMessage(player, "A ce qu’on dit, Jean traîne près de la\nmaison des gros bgs…");
            }
            else
            {
                sendPersonalMessage(player, "Oh te voilà enfin !\n"+
                        "Malheureusement, il est trop tard. Mon frère est déjà parti\n" +
                        "se réfugier dans les profondeurs. J'espère qu’il ne s'est pas\nperdu…\n" +
                        "Laisse moi donc l'œil, que je puisse prévenir d’un futur\nassaut.\n" +
                        "Et ramène ça à mon frère, il l’a oublié en partant.");

                sendPersonalMessage(player, "A ce qu’on dit, Jean traîne près de la\nmaison des gros bgs…");

                controller.setAnnexe2(team.getId());
                player.getInventory().removeItem(sauron);

                ItemStack reward = new ItemStack(Material.HEART_OF_THE_SEA);

                ItemMeta reward_meta = reward.getItemMeta();
                reward_meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Couille de Poséidon (qui pue)");
                reward.setItemMeta(reward_meta);

                (new Utilities()).givePlayerItem(player, reward);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}
