package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.ArtemisController;
import lettoh.dev.controllers.PloutosController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ploutos extends Utils {
    public void handle(Player player, TeamModel team)
    {
        PloutosController ploutos_controller = new PloutosController();

        try
        {
            if (ploutos_controller.hasTeamFinishedPloutos(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Libre à vous de devenir riches. Mais pas trop,\nn’allez quand même pas faire concurrence à Ploutos,\nil pourrait mal le prendre.");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();
                ArrayList<ItemStack> super_emeralds = getPloutosSuperEmeralds(player_inventory);

                if (super_emeralds.size() == 3)
                {
                    try
                    {
                        TeamsController team_controller = new TeamsController();
                        ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());
                        ploutos_controller.addPloutos(team.getId());

                        for (ItemStack super_emerald : super_emeralds)
                        {
                            player_inventory.removeItem(super_emerald);
                        }

                        triggerPloutos(members, team);
                        (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                    }
                    catch (SQLException ex)
                    {
                        System.out.println("Une erreur est survenue dans l'ajout de l'équipe "+team.getName()+" dans la table ploutos");
                        ex.printStackTrace();
                    }
                }
                else
                {
                    sendPersonalMessage(player, "Connaissez-vous bien Ploutos ?\n" +
                            "Si c’était le cas, alors vous seriez sûr qu'il ne vit\nque pour les Super Emeraudes !\n" +
                            "Allez donc chercher ces trois émeraudes au port,\net vous serez largement récompensés.");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée ploutos");
            ex.printStackTrace();
        }
    }

    protected void triggerPloutos(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Ploutos", team);

        ItemStack fortune_book = new ItemStack(Material.ENCHANTED_BOOK, 1);
        EnchantmentStorageMeta meta = (EnchantmentStorageMeta) fortune_book.getItemMeta();
        assert meta != null;
        meta.addStoredEnchant(Enchantment.LOOT_BONUS_BLOCKS, 4, true);
        fortune_book.setItemMeta(meta);

        for (Player player : players)
        {
            (new Utilities()).givePlayerItem(player, fortune_book);
            Utils.sendPersonalMessage(player, "Enfin riches…");
        }
    }

    protected ArrayList<ItemStack> getPloutosSuperEmeralds(PlayerInventory inventory)
    {
        ArrayList<ItemStack> super_emeralds = new ArrayList<>();

        ItemStack first = getSuperEmerald(inventory, "1/3");
        ItemStack second = getSuperEmerald(inventory, "2/3");
        ItemStack third = getSuperEmerald(inventory, "3/3");

        if (first != null) super_emeralds.add(first);
        if (second != null) super_emeralds.add(second);
        if (third != null) super_emeralds.add(third);

        return super_emeralds;
    }

    protected ItemStack getSuperEmerald(Inventory inventory, String index)
    {
        HashMap<Integer, ? extends ItemStack> slots = inventory.all(Material.EMERALD);

        for (Map.Entry<Integer, ? extends ItemStack> set : slots.entrySet()) {
            ItemStack item = set.getValue();
            ItemMeta meta = item.getItemMeta();
            if (meta == null) continue;

            if (meta.getDisplayName().equals("Super Emeraude"))
            {
                List<String> lore = meta.getLore();
                if (lore == null) continue;

                if (lore.size() > 0)
                {
                    if (lore.contains(index)) return item;
                }
            }
        }

        return null;
    }
}
