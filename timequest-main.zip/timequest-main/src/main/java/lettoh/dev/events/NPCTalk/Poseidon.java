package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.AthenaController;
import lettoh.dev.controllers.PoseidonController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.PlayerEffect;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Poseidon extends Utils {

    public void handle(Player player, TeamModel team)
    {
        PoseidonController poseidon_controller = new PoseidonController();

        try
        {
            if (poseidon_controller.hasTeamFinishedPoseidon(team.getId()))
            {
                Utils.sendPersonalMessage(player, "Alors ces fonds marins, ne sont-ils pas merveilleux ?");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();

                if (player_inventory.contains(Material.PUFFERFISH))
                {
                    int total = 0;
                    HashMap<Integer, ? extends ItemStack> slots = player_inventory.all(Material.PUFFERFISH);

                    for (Map.Entry<Integer, ? extends ItemStack> set : slots.entrySet()) {
                        total += set.getValue().getAmount();
                    }

                    if (total >= 32)
                    {
                        try
                        {
                            poseidon_controller.addPoseidon(team.getId());
                            player_inventory.removeItem(new ItemStack(Material.PUFFERFISH, 32));

                            TeamsController team_controller = new TeamsController();
                            ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());

                            triggerPoseidon(members, team);
                            (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                        }
                        catch (SQLException ex)
                        {
                            System.out.println("Une erreur est survenue dans l'ajout de la team "+team.getName()+" à la table poseidon");
                            ex.printStackTrace();
                        }
                    }
                    else
                    {
                        Utils.sendPersonalMessage(player, "Montrez-moi que la mer n’a aucun secret pour vous,\net peut être que Poséidon entendra votre requête.\nPour ce faire, ramenez moi un demi-stack de pufferfish.\nEn suite, l’océan sera vôtre.");
                    }
                }
                else
                {
                    Utils.sendPersonalMessage(player, "Montrez-moi que la mer n’a aucun secret pour vous,\net peut être que Poséidon entendra votre requête.\nPour ce faire, ramenez moi un demi-stack de pufferfish.\nEn suite, l’océan sera vôtre.");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée poseidon");
            ex.printStackTrace();
        }
    }

    protected void triggerPoseidon(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Poséidon", team);

        for (Player player : players)
        {
            (new PlayerEffect(player)).setWaterBreathingEffect();
            Utils.sendPersonalMessage(player, "Vous sentez un changement le long de vos côtes. On dirait des branchies.");
        }
    }
}
