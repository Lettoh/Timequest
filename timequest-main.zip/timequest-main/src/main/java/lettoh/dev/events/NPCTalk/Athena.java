package lettoh.dev.events.NPCTalk;

import lettoh.dev.controllers.AthenaController;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Athena extends Utils {
    public void handle(Player player, TeamModel team)
    {
        AthenaController athena_controller = new AthenaController();

        try
        {
            if (athena_controller.hasTeamFinishedAthena(team.getId()))
            {
                Utils.sendPersonalMessage(player, "L’expérience n’a pas de prix.");
            }
            else
            {
                PlayerInventory player_inventory = player.getInventory();

                if (player_inventory.contains(Material.GOLDEN_APPLE))
                {
                    int total = 0;
                    HashMap<Integer, ? extends ItemStack> slots = player_inventory.all(Material.GOLDEN_APPLE);

                    for (Map.Entry<Integer, ? extends ItemStack> set : slots.entrySet()) {
                        total += set.getValue().getAmount();
                    }

                    if (total >= 16)
                    {
                        try
                        {
                            athena_controller.addAthena(team.getId());
                            player_inventory.removeItem(new ItemStack(Material.GOLDEN_APPLE, 16));

                            TeamsController team_controller = new TeamsController();
                            ArrayList<Player> members = team_controller.findPlayersByTeam(team.getId());

                            triggerAthena(members, team);
                            (new Utilities()).givePlayer(player, Material.EMERALD_BLOCK, 16);
                        }
                        catch (SQLException ex)
                        {
                            System.out.println("Une erreur est survenue dans l'ajout de la team "+team.getName()+" à la table athena");
                            ex.printStackTrace();
                        }
                    }
                    else
                    {
                        Utils.sendPersonalMessage(player, "De l’or, de l’or, de l’or.\nIl en faudra si vous voulez obtenir les faveurs d’Athena.\nLa modique somme de 16 pommes d’or vous conviendrait-elle ?\nEnfin je demande, mais ce n’est pas négociable…");
                    }
                }
                else
                {
                    Utils.sendPersonalMessage(player, "De l’or, de l’or, de l’or.\nIl en faudra si vous voulez obtenir les faveurs d’Athena.\nLa modique somme de 16 pommes d’or vous conviendrait-elle ?\nEnfin je demande, mais ce n’est pas négociable…");
                }
            }
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue lors de l'accès à la base de donnée athena");
            ex.printStackTrace();
        }
    }

    protected void triggerAthena(ArrayList<Player> players, TeamModel team) {

        Utils.broadcastDivinityMessage("Athéna", team);

        for (Player player : players)
        {
            Utils.sendPersonalMessage(player, "Ça serait sympa de pouvoir crafter un seau en verre avec \ndu lapis au milieu. Mais bon, ça donnerait quoi ?");
        }
    }
}
