package lettoh.dev.events;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;

public class UnsafeAnvilEnchantmentEvent implements Listener {
    @EventHandler
    public void OnAnvilUse(PrepareAnvilEvent e)
    {
        AnvilInventory inventory = e.getInventory();

        ItemStack first = inventory.getItem(0);
        ItemStack second = inventory.getItem(1);
        if (first == null || second == null) return;

        ItemStack fortune_book = new ItemStack(Material.ENCHANTED_BOOK, 1);
        EnchantmentStorageMeta meta = (EnchantmentStorageMeta) fortune_book.getItemMeta();
        assert meta != null;
        meta.addStoredEnchant(Enchantment.LOOT_BONUS_BLOCKS, 4, true);
        fortune_book.setItemMeta(meta);

        if (second.equals(fortune_book))
        {
            if (first.getType().toString().toLowerCase().contains("pickaxe")
                    || first.getType().toString().toLowerCase().contains("axe")
                    || first.getType().toString().toLowerCase().contains("hoe"))
            {
                ItemStack result = first.clone();

                result.addUnsafeEnchantment(Enchantment.LOOT_BONUS_BLOCKS, 4);
                e.setResult(result);
            }

        }
    }
}
