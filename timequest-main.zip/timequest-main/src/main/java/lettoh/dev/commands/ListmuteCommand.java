package lettoh.dev.commands;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.PlayerMuteController;
import lettoh.dev.model.PlayerMute;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;

public class ListmuteCommand implements CommandExecutor {

        private final TimeQuest plugin;

        public ListmuteCommand(TimeQuest plugin) {
            this.plugin = plugin;
        }

        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
        {
            if (sender instanceof Player)
            {
                Player player = (Player) sender;
                if (player.isOp())
                {
                    PlayerMuteController controller = new PlayerMuteController();
                    try
                    {
                        ArrayList<PlayerMute> list = controller.getAll();
                        if (list.size() == 0)
                        {
                            player.sendMessage(ChatColor.RED + "Il n'y a aucun joueur mute.");
                            return true;
                        }

                        StringBuilder message = new StringBuilder(ChatColor.GOLD + "Les joueurs mutés sont :\n");
                        for (int i = 0; i < list.size(); i++)
                        {
                            PlayerMute player_mute = list.get(i);
                            UUID player_uuid = UUID.fromString(player_mute.getPlayerUuid());
                            Player muted_player = Bukkit.getPlayer(player_uuid);

                            System.out.println(muted_player);
                            if (muted_player == null) continue;

                            message.append("- ").append(muted_player.getName()).append("\n");
                        }

                        player.sendMessage(message.toString());
                    }
                    catch (SQLException e)
                    {
                        System.out.println("Erreur dans la récupération des joueurs mutes.");
                        e.printStackTrace();
                    }
                }
                else
                {
                    player.sendMessage(ChatColor.RED + "Erreur, vous n'avez pas les permissions requises pour utiliser cette commande.");
                }
            }
            return true;
        }
}
