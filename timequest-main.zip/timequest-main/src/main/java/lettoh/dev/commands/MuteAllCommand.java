package lettoh.dev.commands;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.InfosController;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.SQLException;

public class MuteAllCommand implements CommandExecutor {

    private TimeQuest plugin;

    public MuteAllCommand(TimeQuest plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player)
        {
            Player player = (Player) sender;
            if (player.isOp())
            {
                plugin.chat_disabled = !plugin.chat_disabled;

                try
                {
                    (new InfosController()).setChatDisabled(plugin.chat_disabled);
                }
                catch (SQLException e)
                {
                    System.out.println("Une erreur est survenue dans l'activation/désactivation du chat.");
                    e.printStackTrace();
                }

                if (plugin.chat_disabled)
                {
                    Bukkit.broadcastMessage(ChatColor.GOLD + "Le chat est désormais désactivé.");
                }
                else
                {
                    Bukkit.broadcastMessage(ChatColor.GOLD + "Le chat est désormais activé.");
                }
            }
        }
        return true;
    }
}
