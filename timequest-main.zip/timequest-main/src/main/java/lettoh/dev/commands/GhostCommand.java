package lettoh.dev.commands;

import lettoh.dev.TimeQuest;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GhostCommand implements CommandExecutor {
    private TimeQuest plugin;

    public GhostCommand(TimeQuest plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(sender instanceof Player) {
            Player player = (Player) sender;
            if (player.isOp()) {
                System.out.println("vanish triggered");
                if (plugin.invisible_list.contains(player)) {
                    player.sendMessage("Tu es maintenant visible");
                    for (Player people : Bukkit.getOnlinePlayers()) {
                        people.showPlayer(plugin, player);
                    }
                    plugin.invisible_list.remove(player);
                    Bukkit.broadcastMessage(ChatColor.AQUA + player.getName()+ ChatColor.GOLD +" vient de se connecter.");
                }
                else {
                    player.sendMessage("Tu es maintenant invisible");
                    for (Player people : Bukkit.getOnlinePlayers()) {
                        people.hidePlayer(plugin, player);
                    }
                    plugin.invisible_list.add(player);
                    Bukkit.broadcastMessage(ChatColor.AQUA + player.getName()+ ChatColor.GOLD +" vient de se déconnecter.");
                }
            }
        }
        return true;
    }
}
