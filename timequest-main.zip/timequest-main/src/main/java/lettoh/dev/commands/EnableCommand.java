package lettoh.dev.commands;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.InfosController;
import lettoh.dev.core.Utilities;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.SQLException;

public class EnableCommand extends Utilities implements CommandExecutor {

    private TimeQuest plugin;
    public EnableCommand(TimeQuest plugin)
    {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (sender instanceof Player)
        {
            Player player = (Player) sender;
            if (player.isOp())
            {
                if (args.length != 1) return false;

                try
                {
                    InfosController infos_controller = new InfosController();

                    if (args[0].equalsIgnoreCase("bank"))
                    {
                        infos_controller.setBankDisabled(false);
                        plugin.bank_disabled = false;
                        player.sendMessage(ChatColor.GREEN + "La banque est maintenant activée.");

                        return true;
                    }
                    else if (args[0].equalsIgnoreCase("end"))
                    {
                        infos_controller.setEndEnabled(true);
                        plugin.end_enabled = true;

                        openEnd();

                        player.sendMessage(ChatColor.GREEN + "L'end est maintenant activé.");

                        return true;
                    }
                }
                catch (SQLException e)
                {
                    System.out.println("Une erreur est survenue dans l'attribution des valeurs globales.");
                    e.printStackTrace();
                }
            }
            else
            {
                sendUnrecognizedCommandMessage(player);
            }
        }

        return false;
    }

    protected void openEnd()
    {
        Location l1 = new Location(plugin.getServer().getWorld("world"), 317, 84, -386);
        Location l2 = new Location(plugin.getServer().getWorld("world"), 317, 83, -386);
        Location l3 = new Location(plugin.getServer().getWorld("world"), 317, 82, -386);
        Location l4 = new Location(plugin.getServer().getWorld("world"), 317, 81, -386);

        Location l5 = new Location(plugin.getServer().getWorld("world"), 315, 84, -386);
        Location l6 = new Location(plugin.getServer().getWorld("world"), 315, 83, -386);
        Location l7 = new Location(plugin.getServer().getWorld("world"), 315, 82, -386);
        Location l8 = new Location(plugin.getServer().getWorld("world"), 315, 81, -386);

        Location l9 = new Location(plugin.getServer().getWorld("world"), 313, 84, -386);
        Location l10 = new Location(plugin.getServer().getWorld("world"), 313, 83, -386);
        Location l11 = new Location(plugin.getServer().getWorld("world"), 313, 82, -386);
        Location l12 = new Location(plugin.getServer().getWorld("world"), 313, 81, -386);

        l1.getBlock().setType(Material.AIR);
        l2.getBlock().setType(Material.AIR);
        l3.getBlock().setType(Material.AIR);
        l4.getBlock().setType(Material.AIR);
        l5.getBlock().setType(Material.AIR);
        l6.getBlock().setType(Material.AIR);
        l7.getBlock().setType(Material.AIR);
        l8.getBlock().setType(Material.AIR);
        l9.getBlock().setType(Material.AIR);
        l10.getBlock().setType(Material.AIR);
        l11.getBlock().setType(Material.AIR);
        l12.getBlock().setType(Material.AIR);
    }
}
