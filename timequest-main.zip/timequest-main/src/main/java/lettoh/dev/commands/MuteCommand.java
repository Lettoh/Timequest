package lettoh.dev.commands;

import lettoh.dev.controllers.PlayerMuteController;
import lettoh.dev.database.Database;
import lettoh.dev.model.PlayerMute;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.SQLException;

public class MuteCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player)
        {
            Player player = (Player) sender;
            if (player.isOp())
            {
                Player target = Bukkit.getServer().getPlayer(args[0]);
                if (target != null)
                {
                    try
                    {
                        PlayerMuteController controller = new PlayerMuteController();
                        PlayerMute muted_player = controller.findMutedPlayerByUUID(target.getUniqueId().toString());

                        if (muted_player == null)
                        {
                            muted_player = new PlayerMute(target.getUniqueId().toString());
                            controller.createPlayerMute(muted_player);

                            target.sendMessage(ChatColor.RED + "Tu es mute jusqu'à la fin de l'évent.");
                            target.playSound(target.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0F, 1.0F);
                            player.sendMessage(ChatColor.GREEN + "Le joueur "+target.getName()+" est maintenant mute.");
                        }
                        else
                        {
                            player.sendMessage(ChatColor.RED + "Le joueur est déjà mute.");
                        }
                    }
                    catch (SQLException e)
                    {
                        System.out.println("Une erreur est survenue lors de l'utilisation de la commande /mute");
                        e.printStackTrace();
                    }
                }
                else
                {
                    player.sendMessage(ChatColor.RED + "Renseignez le pseudo du joueur.");
                }
            }
            else
            {
                player.sendMessage(ChatColor.RED + "Erreur, vous n'avez pas les permissions requises pour utiliser cette commande.");
            }
        }
        return true;
    }
}
