package lettoh.dev.commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class QuizCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (player.isOp()) {
                if (args.length > 0) {
                    int i = 0;
                    String question = "=====>  ";
                    while (i < args.length) {
                        question += args[i] + ' ';
                        i++;
                    }
                    question += " <=====";
                    for (Player pl : Bukkit.getOnlinePlayers()) {
                        pl.playSound(pl.getLocation(), Sound.ITEM_GOAT_HORN_SOUND_0, 1.0F, 1.0F);
                    }
                    Bukkit.broadcastMessage(ChatColor.GOLD + question);
                }
                else {
                    player.sendMessage(ChatColor.RED + "Merci de renseigner votre question");
                }
            } else {
                player.sendMessage(ChatColor.RED + "Erreur, vous n'avez pas les permissions requises pour utiliser cette commande.");
            }
        }
        return true;
    }
}
