package lettoh.dev.commands;

import lettoh.dev.core.Utilities;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RewardCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player)
        {
            Player player = (Player) sender;
            if (player.isOp())
            {
                Player winner = Bukkit.getServer().getPlayer(args[0]);
                if (winner != null)
                {
                    Integer amount = Integer.valueOf(args[1]);
                    if (amount > 0)
                    {
                        (new Utilities()).givePlayer(winner, Material.EMERALD, amount);

                        if (amount == 1)
                        {
                            Bukkit.broadcastMessage(ChatColor.GOLD + winner.getName() +ChatColor.GREEN + " a été récompensé de " + amount + " émeraude !");
                        }
                        else
                        {
                            Bukkit.broadcastMessage(ChatColor.GOLD + winner.getName() +ChatColor.GREEN + " a été récompensé de " + amount + " émeraudes !");
                        }

                        winner.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_YES, 1.0F, 1.0F);
                    }
                    else
                    {
                        player.sendMessage(ChatColor.DARK_RED + "Veuillez renseigner un nombre d'émeraudes supérieur à 0.");
                    }
                }
                else
                {
                    player.sendMessage(ChatColor.RED + "Erreur dans le pseudo de la personne.");
                }
            }
            else
            {
                player.sendMessage(ChatColor.RED + "Erreur, vous n'avez pas les permissions requises pour utiliser cette commande.");
            }
        }
        return true;
    }
}
