package lettoh.dev.commands;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;

import java.sql.SQLException;
import java.util.Objects;

public class TeamCommands extends Utilities implements CommandExecutor {

    private final TimeQuest plugin;
    public TeamCommands(TimeQuest plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
    {
        if(sender instanceof Player)
        {
            Player player = (Player) sender;
            if (!player.isOp()) return false;
            if (args[0].equals("team")) return handleTeam(player, args);
            else if (args[0].equals("tp")) return handleTp(player, args);
        }
        return false;
    }

    protected boolean handleTp(Player player, String[] args)
    {
        if (args.length != 2) return false;

        Location benedictions_room = new Location(Bukkit.getWorld("world"), 324, 26, 142, 90, 0);
        Location bank_room = new Location(Bukkit.getWorld("world"), 355, 72, 199, 180, 0);
        Location ranking_room = new Location(Bukkit.getWorld("world"), 370, 72, 208, 90, 0);
        Location spawn = new Location(Bukkit.getWorld("world"), 371, 64, 114);
        Location end = new Location(Bukkit.getWorld("world"), 314.5, 76, -410.5);

        if (args[1].equalsIgnoreCase("benedictions")) player.teleport(benedictions_room);
        else if (args[1].equalsIgnoreCase("bank")) player.teleport(bank_room);
        else if (args[1].equalsIgnoreCase("ranking")) player.teleport(ranking_room);
        else if (args[1].equalsIgnoreCase("spawn")) player.teleport(spawn);
        else if (args[1].equalsIgnoreCase("end")) player.teleport(end);

        return true;
    }

    protected boolean handleTeam(Player player, String[] args)
    {
        TeamsController controller = new TeamsController();

        if (args[1].equals("create"))
        {
            return createTeam(controller, player, args);
        }
        else if (args[1].equals("delete"))
        {
            return deleteTeam(controller, player, args);
        }
        else if (args[1].equals("addplayer"))
        {
            return addPlayerToTeam(controller, player, args);
        }
        else if (args[1].equals("removeplayer"))
        {
            return removePlayerFromTeam(controller, player, args);
        }
        else if (args[1].equals("get"))
        {
            return getTeamInfo(controller, player, args);
        }
        return false;
    }

    protected boolean createTeam(TeamsController controller, Player creator, String[] args)
    {
        if (args.length != 5) return false;
        try
        {
            String name = args[2];
            String tag = "["+args[3]+"] ";
            String color = args[4];
            TeamModel team_model = controller.createTeam(name, tag, color);

            Objects.requireNonNull(plugin.getServer().getScoreboardManager()).getMainScoreboard().registerNewTeam(team_model.getName());
            Team team = Objects.requireNonNull(plugin.getServer().getScoreboardManager()).getMainScoreboard().getTeam(team_model.getName());

            ChatColor corresponding_color = retrieveColor(team_model.getColor());
            assert team != null;

            team.setColor(corresponding_color);
            team.setPrefix(team_model.getTag());

            creator.sendMessage(ChatColor.GREEN + "L'équipe "
                    + corresponding_color + team_model.getName() + " (" +team_model.getTag()+ ")"
                    + ChatColor.GREEN
                    +" a bien été créée."
            );
        }
        catch (SQLException e)
        {
            System.out.println("Erreur dans la création d'une équipe en base de donnée.");
            e.printStackTrace();
        }
        return true;
    }

    protected boolean deleteTeam(TeamsController controller, Player creator, String[] args)
    {
        int team_id = Integer.parseInt(args[2]);

        try
        {
            TeamModel team_model = controller.findTeamById(team_id);
            if (team_model == null)
            {
                creator.sendMessage(ChatColor.RED + "L'équipe n'existe pas dans la base de données.");
                return true;
            }

            controller.deleteTeam(team_id);
            Team team = Objects.requireNonNull(plugin.getServer().getScoreboardManager()).getMainScoreboard().getTeam(team_model.getName());
            if (team == null)
            {
                creator.sendMessage(ChatColor.RED + "L'équipe "
                        + retrieveColor(team_model.getColor()) + team_model.getName() + "(" +team_model.getTag()+ ")"
                        + ChatColor.RED
                        +" n'existe pas dans le scoreboard."
                );
            }
            else
            {
                team.unregister();
                creator.sendMessage(ChatColor.GREEN + "L'équipe "
                        + retrieveColor(team_model.getColor()) + team_model.getName() + " (" +team_model.getTag()+ ")"
                        + ChatColor.GREEN
                        +" a bien été supprimée."
                );
            }
        }
        catch (SQLException e)
        {
            System.out.println("Erreur dans la suppression de l'équipe "+team_id);
            e.printStackTrace();
        }

        return true;
    }

    protected boolean addPlayerToTeam(TeamsController controller, Player creator, String[] args)
    {
        if (args.length != 4) return false;

        Player target = Bukkit.getPlayer(args[2]);
        int team_id = Integer.parseInt(args[3]);

        if (target == null)
        {
            creator.sendMessage(ChatColor.RED + "Le joueur n'existe pas.");
            return true;
        }

        try
        {
            TeamModel team_model = controller.findTeamById(team_id);
            if (team_model == null)
            {
                creator.sendMessage(ChatColor.RED + "L'équipe n'existe pas en base de données.");
                return true;
            }

            controller.addPlayerToTeam(target, team_model);
            Team team = Objects.requireNonNull(plugin.getServer().getScoreboardManager()).getMainScoreboard().getTeam(team_model.getName());
            assert team != null;

            team.addEntry(target.getName());
            creator.sendMessage(ChatColor.GREEN + "Le joueur "
                    + target.getName()
                    + " a bien été ajouté à l'équipe "
                    + retrieveColor(team_model.getColor()) + team_model.getName()
                    + " ("+team_model.getTag()+")."
            );
        }
        catch (Exception e)
        {
            System.out.println("Erreur dans l'ajout du joueur "+args[2]+" dans l'équipe "+team_id);
            e.printStackTrace();
        }

        return true;
    }

    protected boolean removePlayerFromTeam(TeamsController controller, Player creator, String[] args)
    {
        if (args.length != 4) return false;

        Player target = Bukkit.getPlayer(args[2]);
        int team_id = Integer.parseInt(args[3]);

        if (target == null)
        {
            creator.sendMessage(ChatColor.RED + "Le joueur n'existe pas.");
            return true;
        }

        try
        {
            TeamModel team_model = controller.findTeamById(team_id);
            if (team_model == null)
            {
                creator.sendMessage(ChatColor.RED + "L'équipe n'existe pas en base de données.");
                return true;
            }

            controller.removePlayerFromTeam(target, team_model);

            Team team = Objects.requireNonNull(plugin.getServer().getScoreboardManager()).getMainScoreboard().getTeam(team_model.getName());
            assert team != null;

            team.removeEntry(target.getName());
            creator.sendMessage(ChatColor.GREEN + "Le joueur "
                    + target.getName()
                    + " a bien été retiré de l'équipe "
                    + retrieveColor(team_model.getColor()) + team_model.getName()
                    + " ("+team_model.getTag()+")."
            );
        }
        catch (Exception e)
        {
            System.out.println("Erreur dans l'ajout du joueur "+args[2]+" dans l'équipe "+team_id);
            e.printStackTrace();
        }

        return true;
    }

    protected boolean getTeamInfo(TeamsController controller, Player creator, String[] args)
    {
        if (args.length != 3) return false;

        String name = args[2];

        try
        {
            TeamModel team_model = controller.findTeamByName(name);
            if (team_model == null)
            {
                creator.sendMessage(ChatColor.RED + "L'équipe "+ ChatColor.DARK_RED + name+ ChatColor.RED + " n'existe pas");
                return true;
            }

            creator.sendMessage(ChatColor.GREEN + "L'équipe "+name+" a pour ID : "+ChatColor.RED + team_model.getId());
            return true;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return true;
    }
}
