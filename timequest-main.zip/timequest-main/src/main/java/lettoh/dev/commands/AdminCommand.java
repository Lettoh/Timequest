package lettoh.dev.commands;

import lettoh.dev.TimeQuest;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.core.Utilities;
import lettoh.dev.model.TeamModel;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;

import java.sql.SQLException;
import java.util.Objects;

public class AdminCommand extends Utilities implements CommandExecutor {
    private final TimeQuest plugin;

    public AdminCommand(TimeQuest plugin)
    {
        this.plugin = plugin;
    }
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player)
        {
            Player player = (Player) sender;

            if (!player.isOp()) return sendUnrecognizedCommandMessage(player);

            if (args.length != 1) return false;

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null)
            {
                player.sendMessage(ChatColor.RED + "Le joueur n'existe pas.");
                return true;
            }

            if (!target.isOp())
            {
                return addAdmin(player, target);
            }
            else
            {
                return removeAdmin(player, target);
            }
        }
        return true;
    }

    protected boolean addAdmin(Player player, Player target)
    {
        TeamsController controller = new TeamsController();

        try
        {
            TeamModel team_model = controller.findTeamById(1);
            controller.addPlayerToTeam(target, team_model);
            target.setOp(true);

            Team team = Objects.requireNonNull(plugin.getServer().getScoreboardManager()).getMainScoreboard().getTeam(team_model.getName());
            assert team != null;

            team.addEntry(target.getName());
            player.sendMessage(ChatColor.RED + target.getName() + " est maintenant Administrateur.");
            target.sendMessage(ChatColor.GREEN + "Tu es maintenant Administrateur.");
        }
        catch (Exception e)
        {
            System.out.println("Erreur dans l'ajout du joueur en tant qu'Administrateur.");
            e.printStackTrace();
            return true;
        }

        return true;
    }

    protected boolean removeAdmin(Player player, Player target)
    {
        TeamsController controller = new TeamsController();

        try
        {
            TeamModel team_model = controller.findTeamById(1);
            controller.removePlayerFromTeam(target, team_model);
            target.setOp(false);

            Team team = Objects.requireNonNull(plugin.getServer().getScoreboardManager()).getMainScoreboard().getTeam(team_model.getName());
            assert team != null;

            team.removeEntry(target.getName());
            player.sendMessage(ChatColor.RED + target.getName() + " n'est plus Administrateur.");
        }
        catch (Exception e)
        {
            System.out.println("Erreur dans l'ajout du joueur en tant qu'Administrateur.");
            e.printStackTrace();
            return true;
        }

        return true;
    }
}
