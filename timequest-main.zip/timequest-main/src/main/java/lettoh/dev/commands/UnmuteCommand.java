package lettoh.dev.commands;

import lettoh.dev.controllers.PlayerMuteController;
import lettoh.dev.database.Database;
import lettoh.dev.model.PlayerMute;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.SQLException;

public class UnmuteCommand implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player)
        {
            Player player = (Player) sender;
            if (player.isOp())
            {
                Player target = Bukkit.getServer().getPlayer(args[0]);
                if (target != null)
                {
                    try
                    {
                        PlayerMuteController controller = new PlayerMuteController();
                        PlayerMute muted_player = controller.findMutedPlayerByUUID(target.getUniqueId().toString());

                        if (muted_player == null)
                        {
                            player.sendMessage(ChatColor.RED + "Le joueur n'est pas mute.");
                            return true;
                        }

                        controller.deletePlayerMute(muted_player);
                        target.sendMessage(ChatColor.GREEN + "Tu as été unmute, une fois pas deux !");
                        target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
                        player.sendMessage(ChatColor.GREEN + "Le joueur "+target.getName()+" n'est plus mute.");
                    }
                    catch (SQLException e)
                    {
                        System.out.println("Une erreur est survenue lors de l'utilisation de la commande /unmute");
                        e.printStackTrace();
                    }
                }
                else
                {
                    player.sendMessage(ChatColor.RED + "Renseignez le pseudo d'un joueur.");
                }
            }
            else
            {
                player.sendMessage(ChatColor.RED + "Erreur, vous n'avez pas les permissions requises pour utiliser cette commande.");
            }
        }
        return true;
    }
}
