package lettoh.dev.core;

import eu.decentsoftware.holograms.api.DHAPI;
import eu.decentsoftware.holograms.api.holograms.Hologram;
import lettoh.dev.controllers.TeamsController;
import lettoh.dev.model.TeamModel;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Utilities {

    public void loadHologram(Hologram hologram)
    {
        System.out.println("Hologram update "+hologram.getLocation());
        TeamsController team_controller = new TeamsController();
        try
        {
            ArrayList<TeamModel> ranking = team_controller.getByScore();
            List<String> ranking_list = new ArrayList<String>();
            ranking_list.add(ChatColor.GOLD + "===== CLASSEMENT =====");

            int pos = 1;
            for (TeamModel team : ranking)
            {
                ranking_list.add(pos
                        + " - " + retrieveColor(team.getColor()) + team.getName()
                        + " - "
                        + ChatColor.GOLD
                        + team.getScore()
                );
                pos++;
            }

            DHAPI.setHologramLines(hologram, ranking_list);
        }
        catch (SQLException e)
        {
            System.out.println("Une erreur est survenue dans la récupération du ranking");
            e.printStackTrace();
        }
    }

    public void givePlayer(Player player, Material material, int give_amount)
    {
        PlayerInventory player_inventory = player.getInventory();

        for (ItemStack item_inventory : player_inventory.getStorageContents())
        {
            if (give_amount == 0) break;

            if (item_inventory == null)
            {
                System.out.println("item is null");
                int max_stack_size = material.getMaxStackSize();
                if (give_amount > max_stack_size)
                {
                    player_inventory.addItem(new ItemStack(material, max_stack_size));
                    give_amount = give_amount - max_stack_size;
                }
                else
                {
                    player_inventory.addItem(new ItemStack(material, give_amount));
                    give_amount = 0;
                }
            }
            else if (item_inventory.getType().equals(material))
            {
                int inventory_item_amount = item_inventory.getAmount();
                int max_stack_size = item_inventory.getMaxStackSize();

                if (inventory_item_amount == max_stack_size)
                {
                    System.out.println("material found but full");
                    continue;
                }

                System.out.println("material found but not full");

                int difference = max_stack_size - inventory_item_amount;

                if (give_amount <= difference)
                {
                    player_inventory.addItem(new ItemStack(material, give_amount));
                    give_amount = 0;
                }
                else
                {
                    player_inventory.addItem(new ItemStack(material, difference));
                    give_amount = give_amount - difference;
                }
            }
        }

        if (give_amount > 0)
        {
            int max_stack_size = material.getMaxStackSize();

            while (give_amount >= max_stack_size)
            {
                Objects.requireNonNull(player.getServer().getWorld("world")).dropItem(player.getLocation(), new ItemStack(material, max_stack_size));
                give_amount = give_amount - max_stack_size;
            }

            if (give_amount > 0)
            {
                Objects.requireNonNull(player.getServer().getWorld("world")).dropItem(player.getLocation(), new ItemStack(material, give_amount));
            }
        }
    }

    public void givePlayerItem(Player player, ItemStack item)
    {
        Boolean given = false;
        PlayerInventory player_inventory = player.getInventory();

        for (ItemStack item_inventory : player_inventory.getStorageContents())
        {
            if (item_inventory == null)
            {
                player_inventory.addItem(item);
                given = true;
                break;
            }
        }

        if (given == false)
        {
            Objects.requireNonNull(player.getServer().getWorld("world")).dropItem(player.getLocation(), item);
        }
    }

    public boolean sendUnrecognizedCommandMessage(Player player)
    {
        player.sendMessage("Cette commande n'existe pas.");
        return true;
    }

    public ChatColor retrieveColor(String color)
    {
        if (Objects.equals(color, "aqua")) return ChatColor.AQUA;
        if (Objects.equals(color, "black")) return ChatColor.BLACK;
        if (Objects.equals(color, "blue")) return ChatColor.BLUE;
        if (Objects.equals(color, "dark_aqua")) return ChatColor.DARK_AQUA;
        if (Objects.equals(color, "dark_blue")) return ChatColor.DARK_BLUE;
        if (Objects.equals(color, "dark_gray")) return ChatColor.DARK_GRAY;
        if (Objects.equals(color, "dark_green")) return ChatColor.DARK_GREEN;
        if (Objects.equals(color, "dark_purple")) return ChatColor.DARK_PURPLE;
        if (Objects.equals(color, "dark_red")) return ChatColor.DARK_RED;
        if (Objects.equals(color, "gold")) return ChatColor.GOLD;
        if (Objects.equals(color, "gray")) return ChatColor.GRAY;
        if (Objects.equals(color, "green")) return ChatColor.GREEN;
        if (Objects.equals(color, "light_purple")) return ChatColor.LIGHT_PURPLE;
        if (Objects.equals(color, "red")) return ChatColor.RED;
        if (Objects.equals(color, "white")) return ChatColor.WHITE;
        if (Objects.equals(color, "yellow")) return ChatColor.YELLOW;

        return ChatColor.GREEN;
    }
}
