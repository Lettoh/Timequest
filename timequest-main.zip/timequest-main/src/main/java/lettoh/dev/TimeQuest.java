package lettoh.dev;

import eu.decentsoftware.holograms.api.DHAPI;
import eu.decentsoftware.holograms.api.holograms.Hologram;
import lettoh.dev.commands.*;
import lettoh.dev.controllers.InfosController;
import lettoh.dev.controllers.ZeusController;
import lettoh.dev.core.Utilities;
import lettoh.dev.craft.*;
import lettoh.dev.events.*;
import lettoh.dev.events.NPCTalk.Chronos;
import lettoh.dev.events.NPCTalk.Main;
import lettoh.dev.model.TeamModel;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class TimeQuest extends JavaPlugin {

    public ArrayList<Player> invisible_list = new ArrayList<>();
    public ArrayList<Integer> zeus_teams = new ArrayList<>();

    public Boolean end_enabled;
    public Boolean chat_disabled;
    public Boolean bank_disabled;
    @Override
    public void onEnable() {

        loadZeusTeams();
        loadInfos();

        Location hologram_location = new Location(this.getServer().getWorld("world"), 366.5, 74, 210.5);
        Hologram hologram = DHAPI.createHologram("ranking", hologram_location);
        (new Utilities()).loadHologram(hologram);

        // COMMANDS REGISTERING
        this.getCommand("q").setExecutor(new QuizCommand());
        this.getCommand("b").setExecutor(new BroadcastCommand());
        this.getCommand("reward").setExecutor(new RewardCommand());
        this.getCommand("mute").setExecutor(new MuteCommand());
        this.getCommand("unmute").setExecutor(new UnmuteCommand());
        this.getCommand("listmute").setExecutor(new ListmuteCommand(this));
        this.getCommand("ghost").setExecutor(new GhostCommand(this));
        this.getCommand("tq").setExecutor(new TeamCommands(this));
        this.getCommand("admin").setExecutor(new AdminCommand(this));
        this.getCommand("muteall").setExecutor(new MuteAllCommand(this));
        this.getCommand("disable").setExecutor(new DisableCommand(this));
        this.getCommand("enable").setExecutor(new EnableCommand(this));

        // EVENTS REGISTERING
        this.getServer().getPluginManager().registerEvents(new UserJoinEvent(this), this);
        this.getServer().getPluginManager().registerEvents(new UserLeaveEvent(this), this);
        this.getServer().getPluginManager().registerEvents(new Main(this), this);
        this.getServer().getPluginManager().registerEvents(new UserSpeakEvent(this), this);
        this.getServer().getPluginManager().registerEvents(new Chronos(), this);
        this.getServer().getPluginManager().registerEvents(new SpawnProtectionEvent(this), this);
        this.getServer().getPluginManager().registerEvents(new UserConsumeEvent(), this);
        this.getServer().getPluginManager().registerEvents(new BankListener(this), this);
        this.getServer().getPluginManager().registerEvents(new UserFallEvent(), this);
        this.getServer().getPluginManager().registerEvents(new UserCraftEvent(), this);
        this.getServer().getPluginManager().registerEvents(new UnsafeAnvilEnchantmentEvent(), this);
        this.getServer().getPluginManager().registerEvents(new InteractEvent(), this);
        this.getServer().getPluginManager().registerEvents(new PreventEndPortalCreationEvent(this), this);
        this.getServer().getPluginManager().registerEvents(new DisableElytraEvent(), this);


        // CRAFT REGISTERING
        (new XpBottleCraft(this)).register();
        (new TotemCraft(this)).register();
        (new OffrandeUltimeCraft(this)).register();
        (new OffrandePecheCraft(this)).register();
        (new OffrandeNetherCraft(this)).register();
        (new OffrandeMineCraft(this)).register();
        (new OffrandeNatureCraft(this)).register();
        (new OffrandeEndCraft(this)).register();
        (new OffrandeAgriCraft(this)).register();
        (new OffrandeEnchantCraft(this)).register();
    }

    @Override
    public void onDisable() {
        Hologram hologram = DHAPI.getHologram("ranking");
        hologram.delete();
    }

    protected void loadZeusTeams()
    {
        try
        {
            this.zeus_teams = (new ZeusController()).getTeamsIds();
        }
        catch (SQLException ex)
        {
            System.out.println("Une erreur est survenue dans le chargement des équipes de Zeus.");
            ex.printStackTrace();
        }
    }

    protected void loadInfos()
    {
        InfosController infos_controller = new InfosController();
        try
        {
            this.end_enabled = infos_controller.getEndEnabled();
            this.chat_disabled = infos_controller.getChatDisabled();
            this.bank_disabled = infos_controller.getBankDisabled();
        }
        catch (SQLException e)
        {
            System.out.println("Une erreur est survenue dans le chargement des informations globales.");
            e.printStackTrace();
        }
    }
}
